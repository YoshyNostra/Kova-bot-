/**
 * Commandes classiques additionnelles
 * !couleur !hastebin !invites !boosters !permissions !statut !nuke !clone
 */
const { PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');

module.exports = [
  {
    nom: 'couleur',
    async executer(message, args, client) {
      const couleur = (args[0] || '#1B2A4A').toUpperCase();
      if (!/^#[0-9A-F]{6}$/.test(couleur)) return message.reply('Format attendu : `#RRGGBB`.');
      message.reply({ embeds: [new EmbedBuilder().setColor(couleur).setDescription(`Couleur du thème : **${couleur}**`)] });
    }
  },
  {
    nom: 'boosters',
    async executer(message, args, client) {
      const boosters = message.guild.members.cache.filter((m) => m.premiumSince);
      const liste = boosters.size
        ? boosters.map((m) => `${m.user.tag} — <t:${Math.floor(m.premiumSinceTimestamp / 1000)}:R>`).join('\n')
        : 'Aucun booster pour le moment.';
      message.reply({ embeds: [client.util.embed(`🚀 Boosters (${boosters.size})`, liste)] });
    }
  },
  {
    nom: 'statut',
    permission: PermissionFlagsBits.ManageGuild,
    async executer(message, args, client) {
      const membres = message.guild.memberCount;
      const enLigne = message.guild.members.cache.filter((m) => m.presence && m.presence.status !== 'offline').size;
      const enVocal = message.guild.channels.cache
        .filter((c) => c.type === ChannelType.GuildVoice)
        .reduce((a, c) => a + c.members.size, 0);
      message.reply({
        embeds: [client.util.embed('📈 État du serveur',
          null, {
          champs: [
            { name: 'Membres', value: `${membres}`, inline: true },
            { name: 'En ligne', value: `${enLigne}`, inline: true },
            { name: 'En vocal', value: `${enVocal}`, inline: true },
            { name: 'Salons', value: `${message.guild.channels.cache.size}`, inline: true },
            { name: 'Rôles', value: `${message.guild.roles.cache.size}`, inline: true },
            { name: 'Emojis', value: `${message.guild.emojis.cache.size}`, inline: true }
          ]
        })]
      });
    }
  },
  {
    nom: 'invites',
    permission: PermissionFlagsBits.ManageGuild,
    async executer(message, args, client) {
      const invites = await message.guild.invites.fetch().catch(() => null);
      if (!invites) return message.reply('Impossible de récupérer les invitations.');
      const liste = invites.size
        ? invites.map((i) => `\`${i.code}\` — ${i.uses} utilisation(s) par ${i.inviter?.tag || 'inconnu'}`).slice(0, 20).join('\n')
        : 'Aucune invitation active.';
      message.reply({ embeds: [client.util.embed(`🔗 Invitations (${invites.size})`, liste)] });
    }
  },
  {
    nom: 'permissions',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const nom = args.join(' ');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      const perms = role.permissions.toArray().map((p) => `\`${p}\``).join(', ') || 'Aucune permission particulière';
      message.reply({ embeds: [client.util.embed(`🔐 Permissions — ${role.name}`, perms.slice(0, 3900))] });
    }
  },
  {
    nom: 'nuke',
    permission: PermissionFlagsBits.Administrator,
    async executer(message, args, client) {
      const salon = message.channel;
      const position = salon.rawPosition;
      const copie = await salon.clone();
      await copie.setPosition(position);
      await salon.delete();
      copie.send({ embeds: [client.util.embed('💥 Salon réinitialisé', 'Nouveau départ, tous les messages ont été effacés.')] });
    }
  },
  {
    nom: 'clone',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const salon = await message.channel.clone();
      message.reply(`🧬 Salon cloné : ${salon}`);
    }
  },
  {
    nom: 'compte',
    async executer(message, args, client) {
      const id = (args[0] || message.author.id).replace(/[<@!>]/g, '');
      const user = await client.users.fetch(id).catch(() => null);
      if (!user) return message.reply('Utilisateur introuvable.');
      message.reply({
        embeds: [client.util.embed(`🔎 ${user.tag}`, null, {
          thumbnail: user.displayAvatarURL({ size: 256 }),
          champs: [
            { name: 'Identifiant', value: `\`${user.id}\`` },
            { name: 'Compte créé le', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
            { name: 'Bot', value: user.bot ? 'Oui' : 'Non', inline: true }
          ],
          footer: `Ancienneté : ${Math.floor((Date.now() - user.createdTimestamp) / 86_400_000)} jours`
        })]
      });
    }
  }
];
