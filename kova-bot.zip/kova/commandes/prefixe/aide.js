/**
 * Commande classique : !aide
 * Liste l'ensemble des commandes classiques.
 */
const { config } = require('../../core');

module.exports = {
  nom: 'aide',
  async executer(message, args, client) {
    const p = config.bot.prefix;
    const embed = client.util.embed('📖 Commandes classiques — Kova',
      "Voici la liste des commandes à préfixe. Les commandes d'administration sont réservées aux permissions correspondantes.", {
      champs: [
        { name: '🛠️ Installation', value: `\`${p}setup\` — crée rôles, salons et panneaux` },
        { name: '🎫 Tickets', value: `\`${p}panneau\` — publie le panneau de tickets\n\`${p}transcript\` — génère le transcript du ticket courant\n\`${p}classement\` — classement du staff` },
        { name: '🔨 Modération', value: `\`${p}ban @membre [raison]\`\n\`${p}kick @membre [raison]\`\n\`${p}mute @membre [durée] [raison]\`\n\`${p}unmute @membre\`\n\`${p}warn @membre <raison>\`\n\`${p}blacklist @membre <raison>\`\n\`${p}historique @membre\`\n\`${p}clear <nombre>\` — supprime des messages\n\`${p}slowmode <secondes>\`` },
        { name: '🛡️ Sécurité', value: `\`${p}securite\` — état des protections\n\`${p}lock\` / \`${p}unlock\` — verrouille ou déverrouille le salon` },
        { name: '💎 VIP', value: `\`${p}vip @membre\` — attribue un accès VIP\n\`${p}unvip @membre\` — retire l'accès VIP\n\`${p}vips\` — liste les VIP actifs` },
        { name: '🎧 Vocal', value: `\`${p}voc\` — crée un vocal temporaire\n\`${p}voc lock\` / \`${p}voc unlock\`` },
        { name: '🔧 Utilitaires', value: `\`${p}ping\` — latence du bot\n\`${p}serveur\` — informations du serveur\n\`${p}user @membre\` — informations d'un membre\n\`${p}avatar @membre\` — avatar\n\`${p}roleinfo <rôle>\` — informations d'un rôle\n\`${p}annonce <texte>\` — publie une annonce\n\`${p}sondage <question>\` — crée un sondage\n\`${p}say <texte>\` — fait parler le bot` }
      ],
      footer: `Total : ${client.commandesPrefixe.size} commandes classiques · ${client.commandes.size} commandes slash`
    });

    return message.reply({ embeds: [embed] });
  }
};
