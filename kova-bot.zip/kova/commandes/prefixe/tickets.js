/**
 * Commandes classiques : tickets
 * !panneau !transcript !classement
 */
const { config } = require('../../core');
const { PermissionFlagsBits } = require('discord.js');
const { envoyerPanneau, transcript, classementStaff } = require('../../modules/tickets');

module.exports = [
  {
    nom: 'panneau',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      await envoyerPanneau(message.channel, client);
      const rep = await message.reply('Panneau de tickets publié.');
      setTimeout(() => rep.delete().catch(() => {}), 4000);
    }
  },
  {
    nom: 'transcript',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      if (!message.channel.topic || !message.channel.topic.includes('ticket:')) {
        return message.reply("Ce salon n'est pas un ticket.");
      }
      await transcript({ deferReply: async () => {}, editReply: async () => {}, reply: async () => {}, channel: message.channel, guild: message.guild, user: message.author, member: message.member }, client);
    }
  },
  {
    nom: 'classement',
    async executer(message, args, client) {
      message.reply({
        embeds: [client.util.embed('🏆 Classement du staff', classementStaff(client, message.guild))]
      });
    }
  }
];
