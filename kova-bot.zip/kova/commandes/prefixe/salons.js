/**
 * Commandes classiques : gestion des salons et catégories
 * !creersalon !creercategorie !supprimersalon !renommersalon !topic !archive
 */
const { PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = [
  {
    nom: 'creersalon',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const nom = args.join('-').toLowerCase().replace(/[^a-z0-9-]/g, '') || 'nouveau-salon';
      const salon = await message.guild.channels.create({ name: nom, type: ChannelType.GuildText });
      message.reply(`✅ Salon créé : ${salon}`);
    }
  },
  {
    nom: 'creercategorie',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const nom = args.join(' ') || 'Nouvelle catégorie';
      const cat = await message.guild.channels.create({ name: nom, type: ChannelType.GuildCategory });
      message.reply(`✅ Catégorie créée : **${cat.name}**`);
    }
  },
  {
    nom: 'supprimersalon',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      if (!args[0]) return message.reply('Indique le nom ou la mention du salon.');
      const cible = message.guild.channels.cache.get(args[0].replace(/[<#>]/g, ''))
        || message.guild.channels.cache.find((c) => c.name === args[0]);
      if (!cible) return message.reply('Salon introuvable.');
      const nom = cible.name;
      await cible.delete();
      message.channel.send(`🗑️ Salon **${nom}** supprimé.`).catch(() => {});
    }
  },
  {
    nom: 'renommersalon',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const nouveau = args.join('-').toLowerCase().replace(/[^a-z0-9-]/g, '');
      if (!nouveau) return message.reply('Indique le nouveau nom du salon.');
      const ancien = message.channel.name;
      await message.channel.setName(nouveau);
      message.channel.send(`✏️ \`${ancien}\` renommé en \`${nouveau}\`.`);
    }
  },
  {
    nom: 'topic',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const texte = args.join(' ').slice(0, 1024);
      await message.channel.setTopic(texte || null);
      message.reply(texte ? 'Sujet du salon mis à jour.' : 'Sujet du salon effacé.');
    }
  },
  {
    nom: 'archive',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const categorie = message.guild.channels.cache.find((c) => c.name === 'Archives' && c.type === ChannelType.GuildCategory);
      const parent = categorie ? categorie.id : null;
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: false });
      if (parent) await message.channel.setParent(parent, { lockPermissions: false });
      message.reply('📦 Salon archivé : écriture désactivée, déplacé dans les archives.');
    }
  }
];
