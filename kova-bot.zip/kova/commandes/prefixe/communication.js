/**
 * Commandes classiques : annonces et communication
 * !diffusion !embed !dm !reactionrole !reglementauto !bienvenue
 */
const { PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = [
  {
    nom: 'diffusion',
    permission: PermissionFlagsBits.Administrator,
    async executer(message, args, client) {
      const texte = args.join(' ');
      if (!texte) return message.reply('Indique le texte à diffuser.');
      let n = 0;
      for (const salon of message.guild.channels.cache.filter((c) => c.type === 0).values()) {
        const permis = salon.permissionsFor(client.user);
        if (permis?.has(PermissionFlagsBits.SendMessages)) {
          await salon.send({ embeds: [client.util.embed('📢 Diffusion', texte, { footer: `Par ${message.author.username}` })] }).catch(() => {});
          n++;
        }
      }
      message.reply(`📢 Message diffusé dans **${n}** salons.`);
    }
  },
  {
    nom: 'embed',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args) {
      const [titre, ...reste] = args.join(' ').split('|').map((s) => s.trim());
      if (!reste.length) return message.reply('Usage : `!embed Titre | Description`');
      await message.delete().catch(() => {});
      message.channel.send({ embeds: [new EmbedBuilder().setColor(0x1B2A4A).setTitle(titre).setDescription(reste.join(' | '))] });
    }
  },
  {
    nom: 'dm',
    permission: PermissionFlagsBits.Administrator,
    async executer(message, args, client) {
      const cible = await message.guild.members.fetch(args[0].replace(/[<@!>]/g, '')).catch(() => null);
      if (!cible) return message.reply('Membre introuvable.');
      const texte = args.slice(1).join(' ');
      if (!texte) return message.reply('Indique le message à envoyer.');
      await cible.send({ embeds: [client.util.embed(`Message de ${message.guild.name}`, texte)] }).catch(() => {});
      message.reply('✉️ Message privé envoyé.');
    }
  },
  {
    nom: 'reactionrole',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const [titre, ...roles] = args.join(' ').split('|').map((s) => s.trim());
      if (!roles.length) return message.reply('Usage : `!reactionrole <titre> | <rôle1> | <rôle2>`');
      const options = roles
        .map((nom) => {
          const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
          return role ? { label: role.name, value: role.id } : null;
        })
        .filter(Boolean);
      if (!options.length) return message.reply('Aucun rôle trouvé.');

      await message.delete().catch(() => {});
      const menu = new StringSelectMenuBuilder()
        .setCustomId('roles_auto')
        .setPlaceholder('Choisis tes rôles…')
        .setMinValues(0)
        .setMaxValues(options.length)
        .addOptions(options);

      await message.channel.send({
        embeds: [client.util.embed('🎭 Rôles à la carte', titre)],
        components: [new ActionRowBuilder().addComponents(menu)]
      });
    }
  },
  {
    nom: 'bienvenue',
    permission: PermissionFlagsBits.Administrator,
    async executer(message, args, client) {
      const salon = message.mentions.channels.first() || message.channel;
      const texte = args.filter((a) => !a.startsWith('<#')).join(' ') || 'Bienvenue {user} sur {server} !';
      client.db.ecrire('bienvenue', { salon: salon.id, texte, actif: true });
      message.reply(`👋 Message de bienvenue activé dans ${salon}.`);
    }
  }
];
