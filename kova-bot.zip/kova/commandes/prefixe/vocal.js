/**
 * Commande classique : !voc — vocal temporaire.
 */
const { ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  nom: 'voc',
  async executer(message, args, client) {
    const action = (args[0] || '').toLowerCase();
    const vocal = message.member.voice.channel;

    // !voc lock / !voc unlock sur le vocal courant
    if (action === 'lock' || action === 'unlock') {
      if (!vocal) return message.reply("Tu dois être dans un salon vocal.");
      const verrou = action === 'lock';
      await vocal.permissionOverwrites.edit(message.guild.roles.everyone.id, { Connect: !verrou });
      return message.reply(verrou ? `🔒 **${vocal.name}** verrouillé.` : `🔓 **${vocal.name}** déverrouillé.`);
    }

    // !voc @membre [limite] — invite dans son vocal
    if (!vocal) return message.reply("Tu dois être dans un salon vocal pour créer ou gérer un vocal.");

    const nom = client.config.vocal.nomSalonTemporaire.replace('{user}', message.author.username);
    const salon = await message.guild.channels.create({
      name: nom,
      type: ChannelType.GuildVoice,
      parent: vocal.parentId,
      permissionOverwrites: [
        { id: message.guild.roles.everyone.id, allow: [PermissionFlagsBits.Connect] },
        { id: message.author.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ManageChannels] }
      ]
    });

    await message.member.voice.setChannel(salon).catch(() => {});
    message.reply(`🔊 Vocal temporaire créé : **${salon.name}**`);
  }
};
