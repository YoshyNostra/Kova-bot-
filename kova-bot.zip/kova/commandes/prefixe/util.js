/**
 * Commandes classiques : utilitaires
 * !ping !serveur !user !avatar !roleinfo !annonce !sondage !say !boutique !reglement
 */
const { PermissionFlagsBits, ChannelType } = require('discord.js');

async function resoudre(message, arg) {
  if (!arg) return message.member;
  const id = arg.replace(/[<@!>]/g, '');
  return message.guild.members.fetch(id).catch(() => null);
}

module.exports = [
  {
    nom: 'ping',
    async executer(message, args, client) {
      const avant = Date.now();
      const msg = await message.reply('Calcul…');
      const latence = Date.now() - avant;
      msg.edit({ content: null, embeds: [client.util.embed('🏓 Pong',
        `**Bot :** ${client.ws.ping} ms\n**API :** ${latence} ms`)] });
    }
  },
  {
    nom: 'serveur',
    async executer(message, args, client) {
      const g = message.guild;
      const embed = client.util.embed(`📊 ${g.name}`, null, {
        thumbnail: g.iconURL({ size: 256 }),
        champs: [
          { name: 'Membres', value: `${g.memberCount}`, inline: true },
          { name: 'Salons', value: `${g.channels.cache.size}`, inline: true },
          { name: 'Rôles', value: `${g.roles.cache.size}`, inline: true },
          { name: 'Créé le', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
          { name: 'Propriétaire', value: `<@${g.ownerId}>`, inline: true },
          { name: 'Boosts', value: `${g.premiumSubscriptionCount || 0}`, inline: true }
        ],
        footer: `ID : ${g.id}`
      });
      message.reply({ embeds: [embed] });
    }
  },
  {
    nom: 'user',
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const roles = membre.roles.cache.filter((r) => r.name !== '@everyone').map((r) => r.toString()).join(' ') || 'Aucun';
      const embed = client.util.embed(`👤 ${membre.user.tag}`, null, {
        thumbnail: membre.user.displayAvatarURL({ size: 256 }),
        champs: [
          { name: 'Pseudo sur le serveur', value: membre.nickname || membre.user.username, inline: true },
          { name: 'Compte créé le', value: `<t:${Math.floor(membre.user.createdTimestamp / 1000)}:D>`, inline: true },
          { name: 'A rejoint le', value: membre.joinedTimestamp ? `<t:${Math.floor(membre.joinedTimestamp / 1000)}:D>` : 'Inconnu', inline: true },
          { name: `Rôles (${membre.roles.cache.size - 1})`, value: roles.slice(0, 1020) }
        ],
        footer: `ID : ${membre.id}`
      });
      message.reply({ embeds: [embed] });
    }
  },
  {
    nom: 'avatar',
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      message.reply({ embeds: [client.util.embed(`🖼️ Avatar de ${membre.user.username}`, null,
        { image: membre.user.displayAvatarURL({ size: 1024 }) })] });
    }
  },
  {
    nom: 'roleinfo',
    async executer(message, args, client) {
      const nom = args.join(' ');
      if (!nom) return message.reply('Indique le nom d\'un rôle.');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      const embed = client.util.embed(`🎭 ${role.name}`, null, {
        champs: [
          { name: 'Couleur', value: role.hexColor, inline: true },
          { name: 'Membres', value: `${role.members.size}`, inline: true },
          { name: 'Position', value: `${role.position}`, inline: true },
          { name: 'Mentionnable', value: role.mentionable ? 'Oui' : 'Non', inline: true },
          { name: 'Affiché à part', value: role.hoist ? 'Oui' : 'Non', inline: true },
          { name: 'Créé le', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:D>`, inline: true }
        ],
        footer: `ID : ${role.id}`
      });
      message.reply({ embeds: [embed] });
    }
  },
  {
    nom: 'annonce',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args, client) {
      const texte = args.join(' ');
      if (!texte) return message.reply('Indique le texte de l\'annonce.');
      await message.delete().catch(() => {});
      message.channel.send({ embeds: [client.util.embed('📣 Annonce', texte, { footer: `Par ${message.author.username}` })] });
    }
  },
  {
    nom: 'sondage',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args, client) {
      const question = args.join(' ');
      if (!question) return message.reply('Indique la question du sondage.');
      await message.delete().catch(() => {});
      const msg = await message.channel.send({
        embeds: [client.util.embed('📊 Sondage', question, { footer: `Par ${message.author.username}` })]
      });
      await msg.react('✅');
      await msg.react('❌');
    }
  },
  {
    nom: 'say',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args) {
      const texte = args.join(' ');
      if (!texte) return message.reply('Indique le texte à faire dire au bot.');
      await message.delete().catch(() => {});
      message.channel.send(texte);
    }
  },
  {
    nom: 'boutique',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const { envoyerPanneauVip } = require('../../modules/vip');
      await envoyerPanneauVip(message.channel, client);
      const rep = await message.reply('Boutique publiée.');
      setTimeout(() => rep.delete().catch(() => {}), 4000);
    }
  },
  {
    nom: 'reglement',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const texte = args.join(' ');
      if (!texte) return message.reply('Indique le texte du règlement (ou utilise `/setup tout`).');
      message.channel.send({ embeds: [client.util.embed(`📜 Règlement de ${message.guild.name}`, texte)] });
    }
  }
];
