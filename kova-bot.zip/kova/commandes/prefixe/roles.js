/**
 * Commandes classiques : rôles, permissions et vocal
 * !creerrole !supprimerrole !mentionner !rolecouleur !verrou !deverrou !deplace
 */
const { PermissionFlagsBits, ChannelType } = require('discord.js');

async function resoudre(message, arg) {
  if (!arg) return null;
  const id = arg.replace(/[<@!>]/g, '');
  return message.guild.members.fetch(id).catch(() => null);
}

module.exports = [
  {
    nom: 'creerrole',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const nom = args.join(' ') || 'Nouveau rôle';
      const role = await message.guild.roles.create({ name: nom, color: client.util.couleur, reason: `Créé par ${message.author.tag}` });
      message.reply(`✅ Rôle **${role.name}** créé.`);
    }
  },
  {
    nom: 'supprimerrole',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const nom = args.join(' ');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      if (role.managed || role.id === message.guild.id) return message.reply('Ce rôle ne peut pas être supprimé.');
      await role.delete(`Supprimé par ${message.author.tag}`);
      message.reply(`🗑️ Rôle **${nom}** supprimé.`);
    }
  },
  {
    nom: 'rolecouleur',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const nom = args[0];
      const couleur = args[1];
      if (!nom || !couleur) return message.reply('Usage : `!rolecouleur <rôle> <#hex>`');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      await role.setColor(couleur);
      message.reply(`🎨 Couleur de **${role.name}** mise à jour.`);
    }
  },
  {
    nom: 'mentionner',
    permission: PermissionFlagsBits.MentionEveryone,
    async executer(message, args, client) {
      const nom = args.join(' ');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === nom.toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      await role.setMentionable(!role.mentionable);
      message.reply(`Rôle **${role.name}** est maintenant ${role.mentionable ? 'mentionnable' : 'non mentionnable'}.`);
    }
  },
  {
    nom: 'verrou',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const categorie = message.channel.parent;
      const cibles = categorie ? categorie.children.cache : message.guild.channels.cache;
      let n = 0;
      for (const c of cibles.values()) {
        if (c.type === ChannelType.GuildText) {
          await c.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: false }).catch(() => {});
          n++;
        }
      }
      message.reply(`🔒 **${n}** salons verrouillés.`);
    }
  },
  {
    nom: 'deverrou',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args, client) {
      const categorie = message.channel.parent;
      const cibles = categorie ? categorie.children.cache : message.guild.channels.cache;
      let n = 0;
      for (const c of cibles.values()) {
        if (c.type === ChannelType.GuildText) {
          await c.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: null }).catch(() => {});
          n++;
        }
      }
      message.reply(`🔓 **${n}** salons déverrouillés.`);
    }
  },
  {
    nom: 'deplace',
    permission: PermissionFlagsBits.MoveMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const nomVocal = args.slice(1).join(' ');
      const vocal = message.guild.channels.cache.find((c) => c.name.toLowerCase() === nomVocal.toLowerCase() && c.type === ChannelType.GuildVoice);
      if (!vocal) return message.reply('Salon vocal introuvable.');
      if (!membre.voice.channel) return message.reply('Ce membre n\'est pas en vocal.');
      await membre.voice.setChannel(vocal);
      message.reply(`➡️ **${membre.user.tag}** déplacé vers **${vocal.name}**.`);
    }
  }
];
