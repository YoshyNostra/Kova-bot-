/**
 * Commandes classiques : sécurité
 * !securite !lock !unlock
 */
const { config } = require('../../core');
const { PermissionFlagsBits } = require('discord.js');

module.exports = [
  {
    nom: 'securite',
    permission: PermissionFlagsBits.Administrator,
    async executer(message, args, client) {
      const s = client.config.securite;
      const ligne = (v) => (v ? '✅' : '❌');
      message.reply({
        embeds: [client.util.embed('🛡️ État de la sécurité',
          `${ligne(s.antiNuke)} Anti-nuke · ${ligne(s.antiRaid)} Anti-raid · ${ligne(s.filtreComptesRecents)} Comptes récents · ${ligne(s.antiPub)} Anti-pub\n` +
          `**Sanction auto :** ${s.sanctionAuto ? s.sanctionParDefaut : 'désactivée'}`)]
      });
    }
  },
  {
    nom: 'lock',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: false });
      message.reply('🔒 Salon verrouillé.');
    }
  },
  {
    nom: 'unlock',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args) {
      await message.channel.permissionOverwrites.edit(message.guild.roles.everyone.id, { SendMessages: null });
      message.reply('🔓 Salon déverrouillé.');
    }
  }
];
