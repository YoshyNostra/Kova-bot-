/**
 * Commandes classiques : VIP
 * !vip !unvip !vips
 */
const { PermissionFlagsBits } = require('discord.js');
const { attribuerVip, retirerVip } = require('../../modules/vip');

async function resoudre(message, arg) {
  if (!arg) return null;
  const id = arg.replace(/[<@!>]/g, '');
  return message.guild.members.fetch(id).catch(() => null);
}

module.exports = [
  {
    nom: 'vip',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const res = await attribuerVip(message.guild, membre, client);
      message.reply(res.ok
        ? `💎 Accès VIP attribué à **${membre.user.tag}**.`
        : `❌ ${res.raison}`);
    }
  },
  {
    nom: 'unvip',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const ok = await retirerVip(message.guild, membre, client);
      message.reply(ok ? `Accès VIP retiré à **${membre.user.tag}**.` : 'Rôle VIP introuvable.');
    }
  },
  {
    nom: 'vips',
    async executer(message, args, client) {
      const vip = client.db.lire('vip', {});
      const lignes = Object.entries(vip).map(([id, d]) => `<@${id}> — expire <t:${Math.floor(d.expiration / 1000)}:R>`);
      message.reply({ embeds: [client.util.embed('💎 VIP actifs', lignes.length ? lignes.join('\n') : 'Aucun VIP actif.')] });
    }
  }
];
