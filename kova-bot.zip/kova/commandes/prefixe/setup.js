/**
 * Commande classique : !setup
 */
const { PermissionFlagsBits } = require('discord.js');
const { setupComplet } = require('../../modules/setup');

module.exports = {
  nom: 'setup',
  permission: PermissionFlagsBits.Administrator,
  async executer(message, args, client) {
    const attente = await message.reply('⚙️ Installation en cours…');
    const rapport = await setupComplet(message.guild, client);
    attente.edit({
      content: null,
      embeds: [client.util.embed('✅ Installation terminée',
        `**Rôles créés :** ${rapport.roles.length ? rapport.roles.join(', ') : 'aucun (déjà présents)'}\n` +
        `**Salons créés :** ${rapport.salons.length ? rapport.salons.join(', ') : 'aucun (déjà présents)'}` +
        (rapport.erreurs.length ? `\n**Erreurs :** ${rapport.erreurs.join(' | ')}` : ''))]
    });
  }
};
