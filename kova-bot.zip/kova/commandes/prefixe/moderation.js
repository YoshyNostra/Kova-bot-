/**
 * Commandes classiques : modération
 * !ban !kick !mute !unmute !warn !blacklist !historique !clear !slowmode
 */
const { config } = require('../../core');
const { PermissionFlagsBits } = require('discord.js');
const { avertir, blacklister, mute } = require('../../modules/moderation');

/** Résout un membre depuis une mention, un id ou un pseudo */
async function resoudre(message, arg) {
  if (!arg) return null;
  const id = arg.replace(/[<@!>]/g, '');
  return message.guild.members.fetch(id).catch(() => null);
}

async function cibleStaff(message) {
  const roleStaff = message.client.util.role(message.guild, 'staff');
  return roleStaff && message.member.roles.cache.has(roleStaff.id);
}

module.exports = [
  {
    nom: 'ban',
    permission: PermissionFlagsBits.BanMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable. Utilise une mention ou un identifiant.');
      const raison = args.slice(1).join(' ') || 'Non précisée';
      await membre.ban({ reason: `Par ${message.author.tag} — ${raison}` });
      message.reply(`🔨 **${membre.user.tag}** banni. Raison : ${raison}`);
    }
  },
  {
    nom: 'kick',
    permission: PermissionFlagsBits.KickMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const raison = args.slice(1).join(' ') || 'Non précisée';
      await membre.kick(`Par ${message.author.tag} — ${raison}`);
      message.reply(`👢 **${membre.user.tag}** expulsé. Raison : ${raison}`);
    }
  },
  {
    nom: 'mute',
    permission: PermissionFlagsBits.ModerateMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const duree = args[1] && client.util.duree(args[1]) ? args[1] : null;
      const raison = args.slice(duree ? 2 : 1).join(' ') || 'Non précisée';
      await mute(message.guild, membre, duree, raison, message.author, client);
      message.reply(`🔇 **${membre.user.tag}** réduit au silence.`);
    }
  },
  {
    nom: 'unmute',
    permission: PermissionFlagsBits.ModerateMembers,
    async executer(message, args) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      await membre.timeout(null);
      message.reply(`🔊 **${membre.user.tag}** peut de nouveau parler.`);
    }
  },
  {
    nom: 'warn',
    permission: PermissionFlagsBits.ModerateMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const raison = args.slice(1).join(' ') || 'Non précisée';
      const res = await avertir(message.guild, membre, raison, message.author, client);
      message.reply(`⚠️ **${membre.user.tag}** averti (total : ${res.warns}).` +
        (res.blacklist ? '\n🚫 Seuil atteint : blacklist appliquée.' : ''));
    }
  },
  {
    nom: 'blacklist',
    permission: PermissionFlagsBits.BanMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const raison = args.slice(1).join(' ') || 'Non précisée';
      await blacklister(message.guild, membre, raison, message.author, client);
      message.reply(`🚫 **${membre.user.tag}** blacklisté.`);
    }
  },
  {
    nom: 'historique',
    permission: PermissionFlagsBits.ModerateMembers,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const warns = client.db.lire('warns', {});
      const liste = warns[`${message.guild.id}:${membre.id}`] || [];
      const texte = liste.length
        ? liste.map((w, i) => `**${i + 1}.** ${w.raison} — <@${w.par}> (<t:${Math.floor(w.date / 1000)}:R>)`).join('\n')
        : 'Aucun avertissement.';
      message.reply({ embeds: [client.util.embed(`📋 Historique — ${membre.user.tag}`, texte)] });
    }
  },
  {
    nom: 'clear',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args) {
      const nombre = parseInt(args[0], 10);
      if (!nombre || nombre < 1 || nombre > 100) return message.reply('Indique un nombre entre 1 et 100.');
      const supprimes = await message.channel.bulkDelete(nombre + 1, true).catch(() => null);
      if (!supprimes) return message.reply('Suppression impossible (messages trop anciens ?).');
      const rep = await message.channel.send(`🧹 **${supprimes.size - 1}** messages supprimés.`);
      setTimeout(() => rep.delete().catch(() => {}), 4000);
    }
  },
  {
    nom: 'slowmode',
    permission: PermissionFlagsBits.ManageChannels,
    async executer(message, args) {
      const secondes = parseInt(args[0], 10);
      if (isNaN(secondes) || secondes < 0 || secondes > 21600) return message.reply('Indique un nombre entre 0 et 21600.');
      await message.channel.setRateLimitPerUser(secondes);
      message.reply(secondes === 0 ? 'Mode lent désactivé.' : `Mode lent réglé à **${secondes} s**.`);
    }
  }
];
