/**
 * Commandes classiques supplémentaires
 * !serverinfo !membercount !inviteinfo !uptime !botinfo !emoji !banner !id !warns !snipe
 */
const { PermissionFlagsBits } = require('discord.js');

const snipes = new Map();

/** Enregistre un message supprimé pour !snipe (branché par messageDelete) */
function enregistrerSnipe(message) {
  if (!message.guild) return;
  snipes.set(message.channel.id, {
    auteur: message.author,
    contenu: message.content,
    date: Date.now()
  });
}

async function resoudre(message, arg) {
  if (!arg) return message.member;
  const id = arg.replace(/[<@!>]/g, '');
  return message.guild.members.fetch(id).catch(() => null);
}

module.exports = [
  {
    nom: 'snipe',
    permission: PermissionFlagsBits.ManageMessages,
    async executer(message, args, client) {
      const s = snipes.get(message.channel.id);
      if (!s) return message.reply('Aucun message supprimé récemment dans ce salon.');
      message.reply({
        embeds: [client.util.embed('🔍 Dernier message supprimé',
          s.contenu || '*contenu vide ou média*',
          { footer: `${s.auteur.username} · <t:${Math.floor(s.date / 1000)}:R>` })]
      });
    }
  },
  {
    nom: 'uptime',
    async executer(message, args, client) {
      const since = client.readyTimestamp || Date.now();
      const secondes = Math.floor((Date.now() - since) / 1000);
      const j = Math.floor(secondes / 86400);
      const h = Math.floor((secondes % 86400) / 3600);
      const m = Math.floor((secondes % 3600) / 60);
      message.reply(`⏱️ Bot en ligne depuis **${j} j ${h} h ${m} min**.`);
    }
  },
  {
    nom: 'botinfo',
    async executer(message, args, client) {
      const mem = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
      message.reply({
        embeds: [client.util.embed('🤖 Kova',
          'Bot de gestion complète de serveur Discord.',
          {
            thumbnail: client.user.displayAvatarURL({ size: 256 }),
            champs: [
              { name: 'Serveurs', value: `${client.guilds.cache.size}`, inline: true },
              { name: 'Membres', value: `${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)}`, inline: true },
              { name: 'Commandes', value: `${client.commandesPrefixe.size + client.commandes.size}`, inline: true },
              { name: 'Latence', value: `${client.ws.ping} ms`, inline: true },
              { name: 'Mémoire', value: `${mem} Mo`, inline: true },
              { name: 'Node.js', value: process.version, inline: true }
            ]
          })]
      });
    }
  },
  {
    nom: 'membercount',
    async executer(message, args, client) {
      const g = message.guild;
      const humains = g.members.cache.filter((m) => !m.user.bot).size;
      const bots = g.members.cache.filter((m) => m.user.bot).size;
      message.reply(`👥 **${g.memberCount}** membres — ${humains} humains, ${bots} bots.`);
    }
  },
  {
    nom: 'id',
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      message.reply(`Identifiant de **${membre.user.username}** : \`${membre.id}\``);
    }
  },
  {
    nom: 'banner',
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const user = await membre.user.fetch(true).catch(() => membre.user);
      if (!user.bannerURL()) return message.reply('Ce membre n\'a pas de bannière.');
      message.reply({ embeds: [client.util.embed(`🖼️ Bannière de ${user.username}`, null, { image: user.bannerURL({ size: 1024 }) })] });
    }
  },
  {
    nom: 'emoji',
    async executer(message, args, client) {
      const emojis = message.guild.emojis.cache;
      const statiques = emojis.filter((e) => !e.animated).size;
      const animes = emojis.filter((e) => e.animated).size;
      message.reply(`😀 **${emojis.size}** emojis — ${statiques} statiques, ${animes} animés.`);
    }
  },
  {
    nom: 'warns',
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const warns = client.db.lire('warns', {});
      const liste = warns[`${message.guild.id}:${membre.id}`] || [];
      message.reply(`⚠️ **${membre.user.tag}** a **${liste.length}** avertissement(s).`);
    }
  },
  {
    nom: 'voirsalons',
    async executer(message, args, client) {
      const salons = message.guild.channels.cache.filter((c) => c.type === 0).map((c) => c.name).slice(0, 40);
      message.reply({
        embeds: [client.util.embed('📋 Salons du serveur', salons.join(' · ').slice(0, 3900))]
      });
    }
  },
  {
    nom: 'roleadd',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      await membre.roles.add(role);
      message.reply(`✅ Rôle **${role.name}** ajouté à **${membre.user.tag}**.`);
    }
  },
  {
    nom: 'roleremove',
    permission: PermissionFlagsBits.ManageRoles,
    async executer(message, args, client) {
      const membre = await resoudre(message, args[0]);
      if (!membre) return message.reply('Membre introuvable.');
      const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
      if (!role) return message.reply('Rôle introuvable.');
      await membre.roles.remove(role);
      message.reply(`✅ Rôle **${role.name}** retiré à **${membre.user.tag}**.`);
    }
  }
];

module.exports.enregistrerSnipe = enregistrerSnipe;
