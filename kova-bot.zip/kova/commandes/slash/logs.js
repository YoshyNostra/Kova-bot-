/**
 * /logs — gestion et consultation des salons de logs.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { salonLog } = require('../../modules/logs');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Salons de logs')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName('etat').setDescription('Affiche l\'état des 8 salons de logs'))
    .addSubcommand((s) => s.setName('voir').setDescription('Obtient le lien direct d\'un salon de logs')
      .addStringOption((o) => o
        .setName('categorie')
        .setDescription('Catégorie de log')
        .setRequired(true)
        .addChoices(
          { name: 'Messages', value: 'messages' },
          { name: 'Membres', value: 'membres' },
          { name: 'Modération', value: 'moderation' },
          { name: 'Rôles', value: 'roles' },
          { name: 'Salons', value: 'salons' },
          { name: 'Vocal', value: 'vocal' },
          { name: 'Sécurité', value: 'securite' },
          { name: 'Tickets', value: 'tickets' }
        ))),

  permission: PermissionFlagsBits.ManageGuild,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'etat') {
      const cats = ['messages', 'membres', 'moderation', 'roles', 'salons', 'vocal', 'securite', 'tickets'];
      const lignes = cats.map((c) => {
        const actif = client.config.logs[c] !== false;
        const salon = guild.channels.cache.find((x) => x.name === `${client.config.salons.logs}-${c}`)
          || guild.channels.cache.find((x) => x.name === client.config.salons.logs);
        return `${actif ? '🟢' : '⚪'} \`${c}\` → ${salon ? salon : '*salon introuvable*'}`;
      });
      return interaction.reply({
        embeds: [client.util.embed('📋 Salons de logs', lignes.join('\n'))],
        ephemeral: true
      });
    }

    if (sub === 'voir') {
      const categorie = interaction.options.getString('categorie');
      const salon = await salonLog(guild, categorie);
      if (!salon) return interaction.reply({ content: 'Salon de logs introuvable. Lance `/setup salons`.', ephemeral: true });
      return interaction.reply({ content: `Salon : ${salon}`, ephemeral: true });
    }
  }
};
