/**
 * Commandes slash : gestion du serveur
 * /salon creer · /salon supprimer · /role creer · /role donner · /role retirer
 */
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('salon')
      .setDescription('Gestion des salons')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
      .addSubcommand((s) => s.setName('creer').setDescription('Crée un salon')
        .addStringOption((o) => o.setName('nom').setDescription('Nom du salon').setRequired(true))
        .addStringOption((o) => o
          .setName('type').setDescription('Type de salon').setRequired(true)
          .addChoices({ name: 'Textuel', value: 'text' }, { name: 'Vocal', value: 'voice' }, { name: 'Annonces', value: 'news' })))
      .addSubcommand((s) => s.setName('supprimer').setDescription('Supprime un salon')
        .addChannelOption((o) => o.setName('salon').setDescription('Salon à supprimer').setRequired(true)))
      .addSubcommand((s) => s.setName('verrouiller').setDescription('Empêche les membres d\'écrire dans un salon')
        .addChannelOption((o) => o.setName('salon').setDescription('Salon cible').setRequired(true))),
    permission: PermissionFlagsBits.ManageChannels,
    async executer(interaction, client) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'creer') {
        const nom = interaction.options.getString('nom');
        const type = interaction.options.getString('type');
        const map = { text: ChannelType.GuildText, voice: ChannelType.GuildVoice, news: ChannelType.GuildAnnouncement };
        const salon = await interaction.guild.channels.create({ name: nom, type: map[type] });
        return interaction.reply({ content: `✅ Salon créé : ${salon}`, ephemeral: true });
      }

      if (sub === 'supprimer') {
        const salon = interaction.options.getChannel('salon');
        const nom = salon.name;
        await salon.delete();
        return interaction.reply({ content: `🗑️ Salon **${nom}** supprimé.`, ephemeral: true });
      }

      if (sub === 'verrouiller') {
        const salon = interaction.options.getChannel('salon');
        await salon.permissionOverwrites.edit(interaction.guild.roles.everyone.id, { SendMessages: false });
        return interaction.reply({ content: `🔒 ${salon} est verrouillé.`, ephemeral: true });
      }
    }
  },
  {
    data: new SlashCommandBuilder()
      .setName('role')
      .setDescription('Gestion des rôles')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
      .addSubcommand((s) => s.setName('creer').setDescription('Crée un rôle aux couleurs du thème')
        .addStringOption((o) => o.setName('nom').setDescription('Nom du rôle').setRequired(true))
        .addStringOption((o) => o.setName('couleur').setDescription('Couleur #RRGGBB').setRequired(false)))
      .addSubcommand((s) => s.setName('donner').setDescription('Ajoute un rôle à un membre')
        .addUserOption((o) => o.setName('membre').setDescription('Membre').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Rôle').setRequired(true)))
      .addSubcommand((s) => s.setName('retirer').setDescription('Retire un rôle à un membre')
        .addUserOption((o) => o.setName('membre').setDescription('Membre').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Rôle').setRequired(true)))
      .addSubcommand((s) => s.setName('info').setDescription('Informations sur un rôle')
        .addRoleOption((o) => o.setName('role').setDescription('Rôle').setRequired(true))),
    permission: PermissionFlagsBits.ManageRoles,
    async executer(interaction, client) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'creer') {
        const nom = interaction.options.getString('nom');
        const couleur = interaction.options.getString('couleur') || client.config.bot.couleur;
        const role = await interaction.guild.roles.create({ name: nom, color: couleur });
        return interaction.reply({ content: `✅ Rôle **${role.name}** créé.`, ephemeral: true });
      }

      if (sub === 'donner') {
        const membre = interaction.options.getMember('membre');
        const role = interaction.options.getRole('role');
        await membre.roles.add(role);
        return interaction.reply({ content: `✅ **${role.name}** ajouté à **${membre.user.tag}**.`, ephemeral: true });
      }

      if (sub === 'retirer') {
        const membre = interaction.options.getMember('membre');
        const role = interaction.options.getRole('role');
        await membre.roles.remove(role);
        return interaction.reply({ content: `✅ **${role.name}** retiré à **${membre.user.tag}**.`, ephemeral: true });
      }

      if (sub === 'info') {
        const role = interaction.options.getRole('role');
        return interaction.reply({
          embeds: [client.util.embed(`🎭 ${role.name}`, null, {
            champs: [
              { name: 'Couleur', value: role.hexColor, inline: true },
              { name: 'Membres', value: `${role.members.size}`, inline: true },
              { name: 'Position', value: `${role.position}`, inline: true },
              { name: 'Mentionnable', value: role.mentionable ? 'Oui' : 'Non', inline: true },
              { name: 'Affiché à part', value: role.hoist ? 'Oui' : 'Non', inline: true },
              { name: 'Créé le', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:D>`, inline: true }
            ]
          })],
          ephemeral: true
        });
      }
    }
  }
];
