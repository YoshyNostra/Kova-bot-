/**
 * /aide — liste des commandes disponibles.
 */
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aide')
    .setDescription('Affiche l\'aide du bot Kova'),

  async executer(interaction, client) {
    const actif = (m) => (client.config.modules[m] ? '🟢' : '⚪');

    const embed = client.util.embed('📖 Aide — Kova',
      `Commandes slash disponibles sur **${interaction.guild.name}**.`,
      {
        champs: [
          {
            name: '🛠️ Installation',
            value: '`/setup tout` · `/setup roles` · `/setup salons` · `/setup panneaux` · `/setup verifier`'
          },
          {
            name: `${actif('tickets')} 🎫 Tickets`,
            value: '`/ticket panneau` · `/ticket fermer` · `/ticket classement`'
          },
          {
            name: `${actif('moderation')} 🔨 Modération`,
            value: '`/moderation ban` · `kick` · `mute` · `unmute` · `warn` · `blacklist` · `historique`'
          },
          {
            name: `${actif('securite')} 🛡️ Sécurité`,
            value: '`/securite etat` · `/securite verrouiller` · `/securite deverrouiller`'
          },
          {
            name: `${actif('vip')} 💎 VIP`,
            value: '`/vip panneau` · `/vip donner` · `/vip retirer` · `/vip liste`'
          },
          {
            name: `${actif('logs')} 📋 Logs`,
            value: '`/logs etat` · `/logs voir`'
          },
          {
            name: `${actif('backup')} 💾 Sauvegardes`,
            value: '`/backup creer` · `/backup liste` · `/backup telecharger`'
          },
          {
            name: `⌨️ Commandes classiques`,
            value: `Préfixe \`${client.config.bot.prefix}\` — tape \`${client.config.bot.prefix}aide\` pour la liste complète.`
          }
        ],
        footer: 'Tout se configure dans config.json (true/false par module)'
      });

    return interaction.reply({ embeds: [embed] });
  }
};
