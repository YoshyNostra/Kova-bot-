/**
 * Commandes slash : création d'embeds et publication
 * /embed creer · /embed annonce · /embed reglement
 */
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Création et publication d\'embeds')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((s) => s.setName('creer').setDescription('Crée un embed personnalisé dans le salon courant')
      .addStringOption((o) => o.setName('titre').setDescription('Titre de l\'embed').setRequired(true))
      .addStringOption((o) => o.setName('description').setDescription('Description').setRequired(true))
      .addStringOption((o) => o.setName('couleur').setDescription('Couleur #RRGGBB').setRequired(false))
      .addStringOption((o) => o.setName('image').setDescription('URL d\'une image').setRequired(false)))
    .addSubcommand((s) => s.setName('annonce').setDescription('Publie une annonce formatée')
      .addStringOption((o) => o.setName('titre').setDescription('Titre').setRequired(true))
      .addStringOption((o) => o.setName('contenu').setDescription('Contenu').setRequired(true))
      .addChannelOption((o) => o.setName('salon').setDescription('Salon de destination').setRequired(false)))
    .addSubcommand((s) => s.setName('reglement').setDescription('Publie le règlement du serveur dans le salon courant')),

  permission: PermissionFlagsBits.ManageMessages,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'creer') {
      const titre = interaction.options.getString('titre');
      const description = interaction.options.getString('description');
      const couleur = interaction.options.getString('couleur');
      const image = interaction.options.getString('image');

      const embed = new EmbedBuilder().setColor(0x1B2A4A).setTitle(titre).setDescription(description);
      if (couleur && /^#[0-9A-Fa-f]{6}$/.test(couleur)) embed.setColor(couleur);
      if (image) embed.setImage(image);

      await interaction.channel.send({ embeds: [embed] });
      return interaction.reply({ content: '✅ Embed publié.', ephemeral: true });
    }

    if (sub === 'annonce') {
      const titre = interaction.options.getString('titre');
      const contenu = interaction.options.getString('contenu');
      const salon = interaction.options.getChannel('salon') || interaction.channel;

      await salon.send({
        embeds: [client.util.embed(`📣 ${titre}`, contenu, { footer: `Par ${interaction.user.username}` })]
      });
      return interaction.reply({ content: `✅ Annonce publiée dans ${salon}.`, ephemeral: true });
    }

    if (sub === 'reglement') {
      const texte =
        "**1.** Respecte tous les membres, sans exception.\n" +
        "**2.** Aucune publicité ni invitation vers un autre serveur.\n" +
        "**3.** Pas de contenu illégal, haineux ou choquant.\n" +
        "**4.** Pas de spam, de flood ou de mentions abusives.\n" +
        "**5.** Les décisions du staff sont à respecter.\n" +
        "**6.** Un salon = un sujet. Utilise le bon salon.\n\n" +
        "Tout manquement entraîne un avertissement, un mute, voire un bannissement.";
      await interaction.channel.send({
        embeds: [client.util.embed(`📜 Règlement de ${interaction.guild.name}`, texte)]
      });
      return interaction.reply({ content: '✅ Règlement publié.', ephemeral: true });
    }
  }
};
