/**
 * /moderation — ban, kick, mute, warn, blacklist, historique.
 */
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { avertir, mute, blacklister } = require('../../modules/moderation');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('moderation')
    .setDescription('Commandes de modération')
    .addSubcommand((s) => s.setName('ban').setDescription('Bannit un membre')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à bannir').setRequired(true))
      .addStringOption((o) => o.setName('raison').setDescription('Raison').setRequired(false)))
    .addSubcommand((s) => s.setName('kick').setDescription('Expulse un membre')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à expulser').setRequired(true))
      .addStringOption((o) => o.setName('raison').setDescription('Raison').setRequired(false)))
    .addSubcommand((s) => s.setName('mute').setDescription('Réduit un membre au silence')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à mute').setRequired(true))
      .addStringOption((o) => o.setName('duree').setDescription('Durée, ex. 10m, 2h, 1d').setRequired(false))
      .addStringOption((o) => o.setName('raison').setDescription('Raison').setRequired(false)))
    .addSubcommand((s) => s.setName('warn').setDescription('Avertit un membre')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à avertir').setRequired(true))
      .addStringOption((o) => o.setName('raison').setDescription('Raison').setRequired(true)))
    .addSubcommand((s) => s.setName('blacklist').setDescription('Blacklist un membre (bannissement définitif)')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à blacklist').setRequired(true))
      .addStringOption((o) => o.setName('raison').setDescription('Raison').setRequired(true)))
    .addSubcommand((s) => s.setName('historique').setDescription('Affiche l\'historique d\'un membre')
      .addUserOption((o) => o.setName('membre').setDescription('Membre concerné').setRequired(true)))
    .addSubcommand((s) => s.setName('unmute').setDescription('Retire la réduction au silence')
      .addUserOption((o) => o.setName('membre').setDescription('Membre à démute').setRequired(true))),

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const cible = interaction.options.getMember('membre');
    const raison = interaction.options.getString('raison') || 'Non précisée';
    const guild = interaction.guild;

    if (!cible) {
      return interaction.reply({ content: 'Membre introuvable sur ce serveur.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    if (sub === 'ban') {
      await cible.ban({ reason: `Par ${interaction.user.tag} — ${raison}` });
      return interaction.editReply(`🔨 **${cible.user.tag}** a été banni. Raison : ${raison}`);
    }

    if (sub === 'kick') {
      await cible.kick(`Par ${interaction.user.tag} — ${raison}`);
      return interaction.editReply(`👢 **${cible.user.tag}** a été expulsé. Raison : ${raison}`);
    }

    if (sub === 'mute') {
      const duree = interaction.options.getString('duree');
      await mute(guild, cible, duree, raison, interaction.user, client);
      return interaction.editReply(`🔇 **${cible.user.tag}** a été réduit au silence.`);
    }

    if (sub === 'unmute') {
      await cible.timeout(null);
      return interaction.editReply(`🔊 **${cible.user.tag}** peut de nouveau parler.`);
    }

    if (sub === 'warn') {
      const res = await avertir(guild, cible, raison, interaction.user, client);
      return interaction.editReply(
        `⚠️ **${cible.user.tag}** averti (total : ${res.warns}).` +
        (res.blacklist ? '\n🚫 Seuil atteint : blacklist appliquée automatiquement.' : '')
      );
    }

    if (sub === 'blacklist') {
      await blacklister(guild, cible, raison, interaction.user, client);
      return interaction.editReply(`🚫 **${cible.user.tag}** a été blacklisté.`);
    }

    if (sub === 'historique') {
      const warns = client.db.lire('warns', {});
      const liste = warns[`${guild.id}:${cible.id}`] || [];
      const sanctions = liste.length
        ? liste.map((w, i) => `**${i + 1}.** ${w.raison} — <@${w.par}> (<t:${Math.floor(w.date / 1000)}:R>)`).join('\n')
        : 'Aucun avertissement.';

      const embed = client.util.embed(`📋 Historique — ${cible.user.tag}`, sanctions,
        { thumbnail: cible.user.displayAvatarURL({ size: 256 }) });
      return interaction.editReply({ embeds: [embed] });
    }
  }
};
