/**
 * Commandes slash : personnalisation du bot
 * /couleur · /bienvenue · /stats
 */
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('couleur')
      .setDescription('Affiche ou teste une couleur du thème')
      .addStringOption((o) => o.setName('hex').setDescription('Couleur au format #RRGGBB').setRequired(false)),
    async executer(interaction, client) {
      const hex = (interaction.options.getString('hex') || client.config.bot.couleur).toUpperCase();
      if (!/^#[0-9A-F]{6}$/.test(hex)) {
        return interaction.reply({ content: 'Format attendu : `#RRGGBB`.', ephemeral: true });
      }
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(hex)
          .setTitle('🎨 Couleur du thème')
          .setDescription(`Cette couleur est actuellement **${client.config.bot.couleur}** dans \`config.json\`.\n` +
            `Pour la modifier, édite la clé \`bot.couleur\` puis redémarre le bot.`)
          .setFooter({ text: hex })]
      });
    }
  },
  {
    data: new SlashCommandBuilder()
      .setName('bienvenue')
      .setDescription('Configure le message de bienvenue')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand((s) => s.setName('definir').setDescription('Définit le salon et le message de bienvenue')
        .addChannelOption((o) => o.setName('salon').setDescription('Salon d\'accueil').setRequired(true))
        .addStringOption((o) => o.setName('message').setDescription('Message — variables : {user} {server} {membres}').setRequired(true)))
      .addSubcommand((s) => s.setName('desactiver').setDescription('Désactive le message de bienvenue'))
      .addSubcommand((s) => s.setName('apercu').setDescription('Affiche la configuration actuelle')),
    permission: PermissionFlagsBits.Administrator,
    async executer(interaction, client) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'definir') {
        const salon = interaction.options.getChannel('salon');
        const message = interaction.options.getString('message');
        client.db.ecrire('bienvenue', { salon: salon.id, texte: message, actif: true });
        return interaction.reply({ content: `👋 Message de bienvenue activé dans ${salon}.`, ephemeral: true });
      }

      if (sub === 'desactiver') {
        const conf = client.db.lire('bienvenue', { salon: null, texte: '', actif: false });
        conf.actif = false;
        client.db.ecrire('bienvenue', conf);
        return interaction.reply({ content: 'Message de bienvenue désactivé.', ephemeral: true });
      }

      if (sub === 'apercu') {
        const conf = client.db.lire('bienvenue', null);
        if (!conf) return interaction.reply({ content: 'Aucun message de bienvenue configuré.', ephemeral: true });
        return interaction.reply({
          embeds: [client.util.embed('👋 Bienvenue',
            conf.texte.replace('{user}', interaction.user.toString()).replace('{server}', interaction.guild.name).replace('{membres}', `${interaction.guild.memberCount}`),
            { footer: `Salon : ${interaction.guild.channels.cache.get(conf.salon)?.name || 'inconnu'} · ${conf.actif ? 'actif' : 'inactif'}` })],
          ephemeral: true
        });
      }
    }
  },
  {
    data: new SlashCommandBuilder()
      .setName('stats')
      .setDescription('Statistiques d\'utilisation du bot sur ce serveur'),
    async executer(interaction, client) {
      const warns = client.db.lire('warns', {});
      const totalWarns = Object.entries(warns)
        .filter(([k]) => k.startsWith(`${interaction.guild.id}:`))
        .reduce((a, [, v]) => a + v.length, 0);

      const vip = client.db.lire('vip', {});
      const totalVip = Object.keys(vip).length;

      const staff = client.db.lire('staff', {});
      const totalClaims = Object.values(staff).reduce((a, b) => a + b, 0);

      const tickets = client.db.lire('tickets', { compteur: 1 });

      await interaction.reply({
        embeds: [client.util.embed('📊 Statistiques — Kova',
          null, {
          champs: [
            { name: 'Tickets ouverts', value: `${Math.max(0, (tickets.compteur || 1) - 1)}`, inline: true },
            { name: 'Tickets pris en charge', value: `${totalClaims}`, inline: true },
            { name: 'Avertissements', value: `${totalWarns}`, inline: true },
            { name: 'VIP actifs', value: `${totalVip}`, inline: true },
            { name: 'Commandes slash', value: `${client.commandes.size}`, inline: true },
            { name: 'Commandes classiques', value: `${client.commandesPrefixe.size}`, inline: true }
          ],
          footer: 'Kova · thème bleu foncé'
        })]
      });
    }
  }
];
