/**
 * /securite — état et réglages du module sécurité.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('securite')
    .setDescription('Module de sécurité')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName('etat').setDescription('Affiche l\'état des protections'))
    .addSubcommand((s) => s.setName('verrouiller').setDescription('Passe le serveur en vérification maximale'))
    .addSubcommand((s) => s.setName('deverrouiller').setDescription('Revient à la vérification standard')),

  permission: PermissionFlagsBits.Administrator,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const s = client.config.securite;

    if (sub === 'etat') {
      const ligne = (v) => (v ? '✅ activé' : '❌ désactivé');
      return interaction.reply({
        embeds: [client.util.embed('🛡️ État de la sécurité',
          `**Anti-nuke :** ${ligne(s.antiNuke)}\n` +
          `**Anti-raid :** ${ligne(s.antiRaid)}\n` +
          `**Filtre comptes récents :** ${ligne(s.filtreComptesRecents)} (< ${s.filtreComptesRecentsJours} j)\n` +
          `**Anti-pub :** ${ligne(s.antiPub)}\n` +
          `**Sanction auto :** ${s.sanctionAuto ? s.sanctionParDefaut : 'désactivée'}\n\n` +
          `**Seuils / minute**\n` +
          `Rôles : ${s.nombreChangementsRoleParMinute} · Bans : ${s.nombreBansParMinute} · Salons : ${s.nombreCreationsSalonParMinute} · Arrivées : ${s.nombreJoinsParMinute}`
        )],
        ephemeral: true
      });
    }

    if (sub === 'verrouiller') {
      await interaction.guild.setVerificationLevel(4);
      return interaction.reply({ content: '🔒 Vérification maximale activée.', ephemeral: true });
    }

    if (sub === 'deverrouiller') {
      await interaction.guild.setVerificationLevel(2);
      return interaction.reply({ content: '🔓 Vérification standard rétablie.', ephemeral: true });
    }
  }
};
