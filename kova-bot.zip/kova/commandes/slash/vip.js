/**
 * /vip — gestion des accès VIP.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { attribuerVip, retirerVip, envoyerPanneauVip } = require('../../modules/vip');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vip')
    .setDescription('Gestion du module VIP')
    .addSubcommand((s) => s.setName('panneau').setDescription('Publie la boutique VIP dans le salon courant'))
    .addSubcommand((s) => s.setName('donner').setDescription('Attribue un accès VIP')
      .addUserOption((o) => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand((s) => s.setName('retirer').setDescription('Retire l\'accès VIP')
      .addUserOption((o) => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand((s) => s.setName('liste').setDescription('Liste les VIP actifs')),

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'panneau') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ content: 'Permission insuffisante.', ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      await envoyerPanneauVip(interaction.channel, client);
      return interaction.editReply('Boutique VIP publiée.');
    }

    if (sub === 'donner') {
      const membre = interaction.options.getMember('membre');
      const res = await attribuerVip(guild, membre, client);
      return interaction.reply({
        content: res.ok
          ? `💎 Accès VIP attribué à **${membre.user.tag}** jusqu'au <t:${Math.floor(res.expiration / 1000)}:D>.`
          : `❌ ${res.raison}`,
        ephemeral: true
      });
    }

    if (sub === 'retirer') {
      const membre = interaction.options.getMember('membre');
      const ok = await retirerVip(guild, membre, client);
      return interaction.reply({
        content: ok ? `Accès VIP retiré à **${membre.user.tag}**.` : 'Rôle VIP introuvable.',
        ephemeral: true
      });
    }

    if (sub === 'liste') {
      const vip = client.db.lire('vip', {});
      const lignes = Object.entries(vip).map(([id, d]) =>
        `<@${id}> — expire <t:${Math.floor(d.expiration / 1000)}:R>`);
      return interaction.reply({
        embeds: [client.util.embed('💎 VIP actifs', lignes.length ? lignes.join('\n') : 'Aucun VIP actif.')],
        ephemeral: true
      });
    }
  }
};
