/**
 * Commandes slash : vocal
 * /vocal creer · /vocal verrouiller · /vocal expulser
 */
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('vocal')
      .setDescription('Gestion des salons vocaux')
      .addSubcommand((s) => s.setName('creer').setDescription('Crée un salon vocal temporaire et t\'y déplace'))
      .addSubcommand((s) => s.setName('verrouiller').setDescription('Empêche les autres de rejoindre ton vocal'))
      .addSubcommand((s) => s.setName('deverrouiller').setDescription('Autorise à nouveau les autres à rejoindre ton vocal'))
      .addSubcommand((s) => s.setName('expulser').setDescription('Expulse un membre de ton vocal')
        .addUserOption((o) => o.setName('membre').setDescription('Membre à expulser').setRequired(true))),
    async executer(interaction, client) {
      const sub = interaction.options.getSubcommand();
      const vocal = interaction.member.voice.channel;

      if (sub === 'creer') {
        if (!vocal) return interaction.reply({ content: "Rejoins d'abord un salon vocal.", ephemeral: true });
        const nom = client.config.vocal.nomSalonTemporaire.replace('{user}', interaction.user.username);
        const salon = await interaction.guild.channels.create({
          name: nom,
          type: ChannelType.GuildVoice,
          parent: vocal.parentId,
          permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, allow: [PermissionFlagsBits.Connect] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers] }
          ]
        });
        await interaction.member.voice.setChannel(salon).catch(() => {});
        return interaction.reply({ content: `🔊 Vocal temporaire créé : **${salon.name}**`, ephemeral: true });
      }

      if (!vocal) return interaction.reply({ content: "Tu n'es pas dans un salon vocal.", ephemeral: true });

      if (sub === 'verrouiller') {
        await vocal.permissionOverwrites.edit(interaction.guild.roles.everyone.id, { Connect: false });
        return interaction.reply({ content: `🔒 **${vocal.name}** verrouillé.`, ephemeral: true });
      }

      if (sub === 'deverrouiller') {
        await vocal.permissionOverwrites.edit(interaction.guild.roles.everyone.id, { Connect: true });
        return interaction.reply({ content: `🔓 **${vocal.name}** déverrouillé.`, ephemeral: true });
      }

      if (sub === 'expulser') {
        const membre = interaction.options.getMember('membre');
        if (!membre.voice.channel || membre.voice.channel.id !== vocal.id) {
          return interaction.reply({ content: "Ce membre n'est pas dans ton vocal.", ephemeral: true });
        }
        await membre.voice.disconnect();
        return interaction.reply({ content: `👋 **${membre.user.tag}** a été expulsé du vocal.`, ephemeral: true });
      }
    }
  }
];
