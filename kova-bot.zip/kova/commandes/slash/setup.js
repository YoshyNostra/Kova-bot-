/**
 * /setup — installation du bot en 3 minutes.
 * 4 champs à remplir, puis /setup tout crée rôles, salons et panneaux.
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { setupComplet, creerRoles, creerSalons, publierPanneaux } = require('../../modules/setup');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Installe et configure le bot sur ce serveur')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName('tout').setDescription('Crée les rôles, les salons, les panneaux et les logs'))
    .addSubcommand((s) => s.setName('roles').setDescription('Crée uniquement les rôles manquants'))
    .addSubcommand((s) => s.setName('salons').setDescription('Crée uniquement les salons et catégories manquants'))
    .addSubcommand((s) => s.setName('panneaux').setDescription('Republie les panneaux tickets, boutique et règlement'))
    .addSubcommand((s) => s.setName('verifier').setDescription('Vérifie l\'état de l\'installation')),

  permission: PermissionFlagsBits.Administrator,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const guild = interaction.guild;

    if (sub === 'tout') {
      const rapport = await setupComplet(guild, client);
      const embed = client.util.embed('✅ Installation terminée',
        `Configuration de **${guild.name}** effectuée.`,
        {
          champs: [
            { name: 'Rôles créés', value: rapport.roles.length ? rapport.roles.join(', ') : 'Aucun (déjà présents)' },
            { name: 'Salons créés', value: rapport.salons.length ? rapport.salons.join(', ') : 'Aucun (déjà présents)' }
          ],
          footer: rapport.erreurs.length ? `Erreurs : ${rapport.erreurs.join(' | ')}` : 'Kova · setup'
        });
      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'roles') {
      const crees = await creerRoles(guild, client);
      return interaction.editReply({ embeds: [client.util.embed('✅ Rôles',
        crees.length ? `Créés : ${crees.join(', ')}` : 'Tous les rôles existent déjà.')] });
    }

    if (sub === 'salons') {
      const crees = await creerSalons(guild, client);
      return interaction.editReply({ embeds: [client.util.embed('✅ Salons',
        crees.length ? `Créés : ${crees.join(', ')}` : 'Tous les salons existent déjà.')] });
    }

    if (sub === 'panneaux') {
      await publierPanneaux(guild, client);
      return interaction.editReply({ embeds: [client.util.embed('✅ Panneaux',
        'Les panneaux tickets, boutique et règlement ont été publiés.')] });
    }

    if (sub === 'verifier') {
      const attendus = Object.values(client.config.roles);
      const rolesManquants = attendus.filter((n) => !guild.roles.cache.find((r) => r.name === n));
      const salonsAttendus = [
        ...Object.values(client.config.salons).filter((s) => !s.includes('{')),
        ...['messages', 'membres', 'moderation', 'roles', 'salons', 'vocal', 'securite', 'tickets']
          .map((c) => `${client.config.salons.logs}-${c}`)
      ];
      const salonsManquants = salonsAttendus.filter((n) => !guild.channels.cache.find((c) => c.name === n));

      return interaction.editReply({
        embeds: [client.util.embed('🔍 Vérification',
          `**Rôles manquants :** ${rolesManquants.length ? rolesManquants.join(', ') : 'aucun ✅'}\n` +
          `**Salons manquants :** ${salonsManquants.length ? salonsManquants.join(', ') : 'aucun ✅'}`
        )]
      });
    }
  }
};
