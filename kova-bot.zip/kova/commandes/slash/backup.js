/**
 * /backup — sauvegarde et restauration de la structure du serveur.
 */
const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { sauvegarder, listerSauvegardes, DOSSIER } = require('../../modules/backup');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('Sauvegarde des rôles et salons')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName('creer').setDescription('Crée une sauvegarde immédiate'))
    .addSubcommand((s) => s.setName('liste').setDescription('Liste les sauvegardes existantes'))
    .addSubcommand((s) => s.setName('telecharger').setDescription('Télécharge une sauvegarde')
      .addStringOption((o) => o.setName('fichier').setDescription('Nom du fichier').setRequired(true))),

  permission: PermissionFlagsBits.Administrator,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'creer') {
      await interaction.deferReply({ ephemeral: true });
      const chemin = await sauvegarder(interaction.guild, client);
      if (!chemin) return interaction.editReply('❌ Sauvegarde impossible : le dossier n\'est pas accessible en écriture.');
      return interaction.editReply(`💾 Sauvegarde créée : \`${path.basename(chemin)}\``);
    }

    if (sub === 'liste') {
      const fichiers = listerSauvegardes(interaction.guild.id);
      return interaction.reply({
        embeds: [client.util.embed('💾 Sauvegardes',
          fichiers.length ? fichiers.map((f, i) => `**${i + 1}.** \`${f}\``).join('\n') : 'Aucune sauvegarde pour le moment.')],
        ephemeral: true
      });
    }

    if (sub === 'telecharger') {
      const nom = interaction.options.getString('fichier');
      const chemin = path.join(DOSSIER, path.basename(nom));
      if (!fs.existsSync(chemin)) {
        return interaction.reply({ content: 'Fichier introuvable.', ephemeral: true });
      }
      return interaction.reply({
        files: [new AttachmentBuilder(chemin, { name: path.basename(chemin) })],
        ephemeral: true
      });
    }
  }
};
