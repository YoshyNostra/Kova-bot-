/**
 * Commande slash : sauvegarde manuelle et téléchargement
 * /sauvegarde creer · /sauvegarde liste
 */
const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { sauvegarder, listerSauvegardes, capturer, DOSSIER } = require('../../modules/backup');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sauvegarde')
    .setDescription('Sauvegarde de la structure du serveur')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName('creer').setDescription('Crée une sauvegarde immédiate et la télécharge'))
    .addSubcommand((s) => s.setName('liste').setDescription('Liste les sauvegardes disponibles')),

  permission: PermissionFlagsBits.Administrator,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'creer') {
      await interaction.deferReply({ ephemeral: true });
      const chemin = await sauvegarder(interaction.guild, client);
      if (!chemin || !fs.existsSync(chemin)) {
        return interaction.editReply('❌ Sauvegarde impossible : dossier non accessible en écriture.');
      }
      await interaction.editReply({
        content: '💾 Sauvegarde créée.',
        files: [new AttachmentBuilder(chemin, { name: path.basename(chemin) })]
      });
    }

    if (sub === 'liste') {
      const fichiers = listerSauvegardes(interaction.guild.id);
      const apercu = await capturer(interaction.guild);
      await interaction.reply({
        embeds: [client.util.embed('💾 Sauvegardes',
          `**État actuel :** ${apercu.roles.length} rôles · ${apercu.salons.length} salons · ${apercu.membres.length} membres en cache\n` +
          (fichiers.length ? fichiers.map((f, i) => `**${i + 1}.** \`${f}\``).join('\n') : 'Aucune sauvegarde enregistrée.'))],
        ephemeral: true
      });
    }
  }
};
