/**
 * Commandes slash : utilitaires
 * /ping /serveur /user /avatar
 */
const { SlashCommandBuilder } = require('discord.js');

const commandes = [];

commandes.push({
  data: new SlashCommandBuilder().setName('ping').setDescription('Affiche la latence du bot'),
  async executer(interaction, client) {
    const avant = Date.now();
    await interaction.reply('Calcul…');
    const latence = Date.now() - avant;
    await interaction.editReply({
      content: null,
      embeds: [client.util.embed('🏓 Pong', `**Bot :** ${client.ws.ping} ms\n**API :** ${latence} ms`)]
    });
  }
});

commandes.push({
  data: new SlashCommandBuilder().setName('serveur').setDescription('Informations sur le serveur'),
  async executer(interaction, client) {
    const g = interaction.guild;
    await interaction.reply({
      embeds: [client.util.embed(`📊 ${g.name}`, null, {
        thumbnail: g.iconURL({ size: 256 }),
        champs: [
          { name: 'Membres', value: `${g.memberCount}`, inline: true },
          { name: 'Salons', value: `${g.channels.cache.size}`, inline: true },
          { name: 'Rôles', value: `${g.roles.cache.size}`, inline: true },
          { name: 'Créé le', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
          { name: 'Propriétaire', value: `<@${g.ownerId}>`, inline: true },
          { name: 'Boosts', value: `${g.premiumSubscriptionCount || 0}`, inline: true }
        ],
        footer: `ID : ${g.id}`
      })]
    });
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('user')
    .setDescription('Informations sur un membre')
    .addUserOption((o) => o.setName('membre').setDescription('Membre concerné (toi par défaut)').setRequired(false)),
  async executer(interaction, client) {
    const membre = interaction.options.getMember('membre') || interaction.member;
    const roles = membre.roles.cache.filter((r) => r.name !== '@everyone').map((r) => r.toString()).join(' ') || 'Aucun';
    await interaction.reply({
      embeds: [client.util.embed(`👤 ${membre.user.tag}`, null, {
        thumbnail: membre.user.displayAvatarURL({ size: 256 }),
        champs: [
          { name: 'Pseudo sur le serveur', value: membre.nickname || membre.user.username, inline: true },
          { name: 'Compte créé le', value: `<t:${Math.floor(membre.user.createdTimestamp / 1000)}:D>`, inline: true },
          { name: 'A rejoint le', value: membre.joinedTimestamp ? `<t:${Math.floor(membre.joinedTimestamp / 1000)}:D>` : 'Inconnu', inline: true },
          { name: `Rôles (${membre.roles.cache.size - 1})`, value: roles.slice(0, 1020) }
        ],
        footer: `ID : ${membre.id}`
      })]
    });
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Affiche l\'avatar d\'un membre')
    .addUserOption((o) => o.setName('membre').setDescription('Membre concerné (toi par défaut)').setRequired(false)),
  async executer(interaction, client) {
    const membre = interaction.options.getMember('membre') || interaction.member;
    await interaction.reply({
      embeds: [client.util.embed(`🖼️ Avatar de ${membre.user.username}`, null,
        { image: membre.user.displayAvatarURL({ size: 1024 }) })]
    });
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('annonce')
    .setDescription('Publie une annonce dans le salon courant')
    .addStringOption((o) => o.setName('texte').setDescription('Contenu de l\'annonce').setRequired(true)),
  async executer(interaction, client) {
    const texte = interaction.options.getString('texte');
    await interaction.reply({
      embeds: [client.util.embed('📣 Annonce', texte, { footer: `Par ${interaction.user.username}` })]
    });
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('sondage')
    .setDescription('Crée un sondage oui/non')
    .addStringOption((o) => o.setName('question').setDescription('Question du sondage').setRequired(true)),
  async executer(interaction, client) {
    const question = interaction.options.getString('question');
    await interaction.reply({
      embeds: [client.util.embed('📊 Sondage', question, { footer: `Par ${interaction.user.username}` })]
    });
    const msg = await interaction.fetchReply();
    await msg.react('✅');
    await msg.react('❌');
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprime des messages dans le salon courant')
    .setDefaultMemberPermissions(0)
    .addIntegerOption((o) => o.setName('nombre').setDescription('Nombre de messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)),
  permission: require('discord.js').PermissionFlagsBits.ManageMessages,
  async executer(interaction, client) {
    const nombre = interaction.options.getInteger('nombre');
    await interaction.deferReply({ ephemeral: true });
    const supprimes = await interaction.channel.bulkDelete(nombre, true).catch(() => null);
    await interaction.editReply(supprimes
      ? `🧹 **${supprimes.size}** messages supprimés.`
      : 'Suppression impossible (messages trop anciens ?).');
  }
});

commandes.push({
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Règle le mode lent du salon')
    .addIntegerOption((o) => o.setName('secondes').setDescription('Secondes entre deux messages (0 pour désactiver)').setRequired(true).setMinValue(0).setMaxValue(21600)),
  permission: require('discord.js').PermissionFlagsBits.ManageChannels,
  async executer(interaction, client) {
    const secondes = interaction.options.getInteger('secondes');
    await interaction.channel.setRateLimitPerUser(secondes);
    await interaction.reply({
      content: secondes === 0 ? 'Mode lent désactivé.' : `Mode lent réglé à **${secondes} s**.`,
      ephemeral: true
    });
  }
});

module.exports = commandes;
