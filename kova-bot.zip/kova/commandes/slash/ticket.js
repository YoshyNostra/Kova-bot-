/**
 * /ticket — gestion des tickets (panneau, classement, fermeture).
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { envoyerPanneau, fermer, classementStaff } = require('../../modules/tickets');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Gestion des tickets')
    .addSubcommand((s) => s.setName('panneau').setDescription('Publie le panneau d\'ouverture de ticket dans le salon courant'))
    .addSubcommand((s) => s.setName('fermer').setDescription('Ferme le ticket courant avec transcript'))
    .addSubcommand((s) => s.setName('classement').setDescription('Affiche le classement du staff par tickets pris en charge')),

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'panneau') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ content: 'Permission insuffisante.', ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      await envoyerPanneau(interaction.channel, client);
      return interaction.editReply('Panneau publié.');
    }

    if (sub === 'fermer') {
      if (!interaction.channel.topic || !interaction.channel.topic.includes('ticket:')) {
        return interaction.reply({ content: 'Ce salon n\'est pas un ticket.', ephemeral: true });
      }
      return fermer(interaction, client);
    }

    if (sub === 'classement') {
      return interaction.reply({
        embeds: [client.util.embed('🏆 Classement du staff',
          classementStaff(client, interaction.guild),
          { footer: 'Basé sur les tickets pris en charge' })]
      });
    }
  }
};
