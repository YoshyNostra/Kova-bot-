/**
 * Commandes slash : équipe et gestion interne
 * /staff classement · /staff note · /staff absent
 */
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { classementStaff } = require('../../modules/tickets');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('staff')
    .setDescription('Gestion de l\'équipe')
    .addSubcommand((s) => s.setName('classement').setDescription('Classement des tickets pris en charge'))
    .addSubcommand((s) => s.setName('note').setDescription('Ajoute une note interne à un membre du staff')
      .addUserOption((o) => o.setName('membre').setDescription('Membre du staff').setRequired(true))
      .addStringOption((o) => o.setName('note').setDescription('Note interne').setRequired(true)))
    .addSubcommand((s) => s.setName('notes').setDescription('Affiche les notes internes d\'un membre')
      .addUserOption((o) => o.setName('membre').setDescription('Membre du staff').setRequired(true)))
    .addSubcommand((s) => s.setName('liste').setDescription('Liste les membres du staff et des modérateurs')),

  permission: PermissionFlagsBits.ManageGuild,

  async executer(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'classement') {
      return interaction.reply({
        embeds: [client.util.embed('🏆 Classement du staff', classementStaff(client, guild),
          { footer: 'Basé sur les tickets pris en charge' })]
      });
    }

    if (sub === 'note') {
      const cible = interaction.options.getMember('membre');
      const note = interaction.options.getString('note');
      const notes = client.db.lire('staff_notes', {});
      const cle = `${guild.id}:${cible.id}`;
      notes[cle] = notes[cle] || [];
      notes[cle].push({ note, par: interaction.user.id, date: Date.now() });
      client.db.ecrire('staff_notes', notes);
      return interaction.reply({ content: `📝 Note ajoutée sur **${cible.user.tag}**.`, ephemeral: true });
    }

    if (sub === 'notes') {
      const cible = interaction.options.getMember('membre');
      const notes = client.db.lire('staff_notes', {});
      const liste = notes[`${guild.id}:${cible.id}`] || [];
      const texte = liste.length
        ? liste.map((n, i) => `**${i + 1}.** ${n.note} — <@${n.par}> (<t:${Math.floor(n.date / 1000)}:R>)`).join('\n')
        : 'Aucune note.';
      return interaction.reply({ embeds: [client.util.embed(`📝 Notes — ${cible.user.tag}`, texte)], ephemeral: true });
    }

    if (sub === 'liste') {
      const roleStaff = client.util.role(guild, 'staff');
      const roleModo = client.util.role(guild, 'moderateur');
      const staff = roleStaff ? roleStaff.members.map((m) => `${m.user.tag}`) : [];
      const modo = roleModo ? roleModo.members.map((m) => `${m.user.tag}`) : [];
      return interaction.reply({
        embeds: [client.util.embed('👥 Équipe',
          `**Staff (${staff.length})**\n${staff.join('\n') || 'Aucun'}\n\n**Modérateurs (${modo.length})**\n${modo.join('\n') || 'Aucun'}`)],
        ephemeral: true
      });
    }
  }
};
