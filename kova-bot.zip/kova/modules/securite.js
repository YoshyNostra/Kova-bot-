/**
 * Module : Sécurité
 * Anti-nuke, anti-raid, filtre de comptes récents, anti-pub.
 */
const { config } = require('../core');
const { PermissionFlagsBits } = require('discord.js');

// Compteurs glissants par serveur / utilisateur
const compteurs = new Map();

function cle(guildId, userId) {
  return `${guildId}:${userId}`;
}

function trop(guildId, userId, type, limite) {
  const k = `${cle(guildId, userId)}:${type}`;
  const maintenant = Date.now();
  const fenetre = 60_000;
  const liste = (compteurs.get(k) || []).filter((t) => maintenant - t < fenetre);
  liste.push(maintenant);
  compteurs.set(k, liste);
  return liste.length > limite;
}

/** Sanction auto appliquée par les modules de sécurité */
async function sanctionner(guild, membre, raison, client) {
  if (!config.securite.sanctionAuto) return;
  const mode = config.securite.sanctionParDefaut;

  try {
    if (mode === 'ban') {
      await guild.members.ban(membre.id, { reason: `Kova Sécurité : ${raison}` });
    } else if (mode === 'kick') {
      await membre.kick(`Kova Sécurité : ${raison}`);
    } else {
      await membre.timeout(24 * 60 * 60 * 1000, `Kova Sécurité : ${raison}`);
    }
  } catch (e) {
    console.error('[securite:sanction]', e.message);
  }

  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(guild, 'Sanction automatique',
      `${membre.user} sanctionné (**${mode}**).\nRaison : ${raison}`, [], client);
  }
}

/** Anti-pub / filtre de liens — appelé depuis messageCreate */
async function gererAntiPub(message, client) {
  if (!message.member) return false;
  // Le staff est exempté
  const roleStaff = client.util.role(message.guild, 'staff');
  const roleModo = client.util.role(message.guild, 'moderateur');
  if ((roleStaff && message.member.roles.cache.has(roleStaff.id)) ||
      (roleModo && message.member.roles.cache.has(roleModo.id))) return false;

  const contenu = message.content.toLowerCase();
  const trouve = config.securite.listeMotsInterdits.find((m) => contenu.includes(m.toLowerCase()));
  if (!trouve) return false;

  await message.delete().catch(() => {});
  await message.channel.send({
    content: `${message.author}, la publication de liens ou d'invitations n'est pas autorisée ici.`
  }).then((m) => setTimeout(() => m.delete().catch(() => {}), 6000)).catch(() => {});

  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(message.guild, 'Anti-pub',
      `${message.author} — message supprimé dans ${message.channel}.\nTerme détecté : \`${trouve}\``, [], client);
  }

  if (trop(message.guild.id, message.author.id, 'pub', 3)) {
    await sanctionner(message.guild, message.member, 'récidive de publicité', client);
  }
  return true;
}

/** Filtre de comptes récents + anti-raid — appelé depuis guildMemberAdd */
async function verifierArrivee(member, client) {
  const guild = member.guild;
  const age = Date.now() - member.user.createdTimestamp;
  const jours = config.securite.filtreComptesRecentsJours * 24 * 60 * 60 * 1000;

  // Filtre de comptes récents
  if (config.securite.filtreComptesRecents && age < jours) {
    await sanctionner(guild, member, `compte créé il y a moins de ${config.securite.filtreComptesRecentsJours} jours`, client);
    return true;
  }

  // Anti-raid : trop d'arrivées en une minute
  if (config.securite.antiRaid && trop(guild.id, 'raid', 'joins', config.securite.nombreJoinsParMinute)) {
    if (config.modules.logs) {
      const { logSecurite } = require('./logs');
      await logSecurite(guild, '⚠️ Raid détecté',
        `Plus de ${config.securite.nombreJoinsParMinute} arrivées en une minute. Activation du mode raid.`, [], client);
    }
    // Passe le serveur en vérification maximale (0 = le plus strict)
    await guild.setVerificationLevel(4).catch(() => {});
    return false;
  }
  return false;
}

/** Anti-nuke sur les changements de rôles — appelé depuis guildMemberUpdate */
async function signalerChangementRole(guild, membre, ajoutes, retires, client) {
  // On identifie l'auteur via l'audit log
  let auteur = null;
  try {
    const { AuditLogEvent } = require('discord.js');
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberRoleUpdate, limit: 1 });
    const entree = logs.entries.first();
    if (entree && Date.now() - entree.createdTimestamp < 10_000) auteur = entree.executor;
  } catch { /* audit log non accessible */ }

  if (!auteur || auteur.bot || auteur.id === guild.ownerId) return;
  const roleStaff = client.util.role(guild, 'staff');
  if (roleStaff && guild.members.cache.get(auteur.id)?.roles.cache.has(roleStaff.id)) return;

  const limite = config.securite.nombreChangementsRoleParMinute;
  if (!trop(guild.id, auteur.id, 'roles', limite)) return;

  const membreAuteur = guild.members.cache.get(auteur.id);
  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(guild, 'Anti-nuke — changements de rôles',
      `${auteur} a modifié plus de ${limite} rôles en une minute.\nCible : ${membre.user}`, [], client);
  }
  if (membreAuteur) await sanctionner(guild, membreAuteur, 'changements de rôles massifs (anti-nuke)', client);
}

/** Anti-nuke sur les suppressions de salons — appelé depuis channelDelete */
async function signalerSuppressionSalon(guild, salon, client) {
  if (!config.securite.antiNuke) return;
  let auteur = null;
  try {
    const { AuditLogEvent } = require('discord.js');
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 });
    const entree = logs.entries.first();
    if (entree && Date.now() - entree.createdTimestamp < 10_000) auteur = entree.executor;
  } catch { /* audit log non accessible */ }

  if (!auteur || auteur.bot || auteur.id === guild.ownerId) return;

  if (!trop(guild.id, auteur.id, 'salons', config.securite.nombreCreationsSalonParMinute)) return;

  const membre = guild.members.cache.get(auteur.id);
  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(guild, 'Anti-nuke — salons supprimés',
      `${auteur} a supprimé plusieurs salons très rapidement.\nSalon : \`${salon.name}\``, [], client);
  }
  if (membre) await sanctionner(guild, membre, 'suppressions de salons massives (anti-nuke)', client);
}

/** Anti-nuke sur les bans — appelé depuis guildBanAdd */
async function signalerBan(guild, ban, client) {
  if (!config.securite.antiNuke) return;
  let auteur = null;
  try {
    const { AuditLogEvent } = require('discord.js');
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 1 });
    const entree = logs.entries.first();
    if (entree && Date.now() - entree.createdTimestamp < 10_000) auteur = entree.executor;
  } catch { /* audit log non accessible */ }

  if (!auteur || auteur.bot || auteur.id === guild.ownerId) return;

  if (!trop(guild.id, auteur.id, 'bans', config.securite.nombreBansParMinute)) return;

  const membre = guild.members.cache.get(auteur.id);
  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(guild, 'Anti-nuke — bannissements massifs',
      `${auteur} a banni plusieurs membres très rapidement.\nDernière cible : ${ban.user}`, [], client);
  }
  if (membre) await sanctionner(guild, membre, 'bannissements massifs (anti-nuke)', client);
}

function initialiserSecurite(client) {
  console.log('   🛡️ Module sécurité : anti-nuke, anti-raid, filtre comptes récents, anti-pub');
}

module.exports = {
  initialiserSecurite,
  gererAntiPub,
  verifierArrivee,
  signalerChangementRole,
  signalerSuppressionSalon,
  signalerBan,
  sanctionner,
  trop
};
