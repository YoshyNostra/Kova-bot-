/**
 * Module : Tickets
 * Menu déroulant, transcripts HTML, claim, classement du staff.
 */
const { config } = require('../core');
const {
  ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionFlagsBits, AttachmentBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const DOSSIER_TRANSCRIPTS = path.join(__dirname, '..', 'transcripts');
if (!fs.existsSync(DOSSIER_TRANSCRIPTS)) fs.mkdirSync(DOSSIER_TRANSCRIPTS, { recursive: true });

let compteur = 1;

function restaurerCompteurs(client) {
  const stats = client.db.lire('tickets', { compteur: 1 });
  compteur = stats.compteur || 1;
  console.log('   🎫 Module tickets : menu déroulant, transcripts HTML, claim, classement');
}

/** Construit et envoie le panneau de tickets */
async function envoyerPanneau(channel, client) {
  const embed = client.util.embed(
    '🎫 Ouvrir un ticket',
    "Sélectionne la catégorie correspondant à ta demande dans le menu ci-dessous.\n" +
    "Un salon privé sera créé automatiquement, visible par toi et par l'équipe."
  );

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_ouvrir')
    .setPlaceholder('Choisis une catégorie…')
    .addOptions(config.tickets.categories.map((c, i) => ({
      label: c.label,
      value: `cat_${i}`,
      description: c.description?.slice(0, 100),
      emoji: c.emoji
    })));

  await channel.send({
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(menu)]
  });
}

/** Crée le salon de ticket après sélection de catégorie */
async function ouvrirDepuisSelection(interaction, client) {
  await interaction.deferReply({ ephemeral: true });
  const index = parseInt(interaction.values[0].replace('cat_', ''), 10);
  const categorie = config.tickets.categories[index] || { label: 'Ticket', emoji: '🎫' };

  const guild = interaction.guild;
  const membre = interaction.member;

  // Anti-doublon : un seul ticket ouvert par membre
  const existant = guild.channels.cache.find((c) =>
    c.name === `${config.salons.ticketOuvert.replace('{user}', membre.user.username.toLowerCase())}` ||
    (c.topic && c.topic.includes(`ticket:${membre.id}`))
  );
  if (existant) {
    return interaction.editReply(`Tu as déjà un ticket ouvert : ${existant}`);
  }

  const parent = guild.channels.cache.find((c) =>
    c.name === config.salons.categorieTickets && c.type === ChannelType.GuildCategory);

  const roleStaff = client.util.role(guild, 'staff');
  const roleModo = client.util.role(guild, 'moderateur');

  const surcharges = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: membre.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ReadMessageHistory] },
    { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] }
  ];
  if (roleStaff) surcharges.push({ id: roleStaff.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
  if (roleModo) surcharges.push({ id: roleModo.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });

  const numero = String(compteur).padStart(4, '0');
  compteur += 1;
  client.db.ecrire('tickets', { compteur });

  const salon = await guild.channels.create({
    name: `ticket-${numero}`,
    type: ChannelType.GuildText,
    parent: parent ? parent.id : null,
    topic: `ticket:${membre.id}|categorie:${categorie.label}|ouvert:${Date.now()}`,
    permissionOverwrites: surcharges
  });

  const embed = client.util.embed(
    `${categorie.emoji} Ticket ${numero} — ${categorie.label}`,
    `Bienvenue ${membre}, merci d'avoir ouvert un ticket.\n\n` +
    `Décris ta demande en détail, l'équipe te répondra dès que possible.\n` +
    `**Catégorie :** ${categorie.label}\n` +
    `**Ouvert le :** ${client.util.maintenant()}`
  );

  const boutons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('staff_claim').setLabel('Claim').setEmoji('🙋').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('staff_close').setLabel('Fermer').setEmoji('🔒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('staff_transcript').setLabel('Transcript').setEmoji('📄').setStyle(ButtonStyle.Secondary)
  );

  await salon.send({ content: `${membre} ${roleStaff ? roleStaff : ''}`, embeds: [embed], components: [boutons] });
  await interaction.editReply(`Ton ticket a été créé : ${salon}`);

  if (config.modules.logs) {
    const { logTicket } = require('./logs');
    await logTicket(guild, 'Ticket ouvert',
      `${membre.user} a ouvert un ticket (**${categorie.label}**) → ${salon}`, [], client);
  }
}

/** Routage des boutons du module tickets */
async function gererInteractionTicket(interaction, client) {
  const id = interaction.customId;

  if (id === 'staff_claim') return claim(interaction, client);
  if (id === 'staff_close') return fermer(interaction, client);
  if (id === 'staff_transcript') return transcript(interaction, client);
}

/** Claim : le membre du staff s'attribue le ticket */
async function claim(interaction, client) {
  const roleStaff = client.util.role(interaction.guild, 'staff');
  const roleModo = client.util.role(interaction.guild, 'moderateur');
  const estStaff = (roleStaff && interaction.member.roles.cache.has(roleStaff.id)) ||
                   (roleModo && interaction.member.roles.cache.has(roleModo.id));
  if (!estStaff) {
    return interaction.reply({ content: "Seul le staff peut prendre en charge un ticket.", ephemeral: true });
  }

  const salon = interaction.channel;
  const topic = salon.topic || '';
  if (topic.includes('claim:')) {
    const prisPar = topic.match(/claim:(\d+)/)[1];
    return interaction.reply({ content: `Ce ticket est déjà pris en charge par <@${prisPar}>.`, ephemeral: true });
  }

  await salon.setTopic(`${topic}|claim:${interaction.user.id}`).catch(() => {});
  await interaction.reply({
    embeds: [client.util.embed('🙋 Ticket pris en charge',
      `**${interaction.user.tag}** s'occupe de ce ticket.\n${client.util.maintenant()}`)]
  });

  // Classement du staff
  const stats = client.db.lire('staff', {});
  stats[interaction.user.id] = (stats[interaction.user.id] || 0) + 1;
  client.db.ecrire('staff', stats);

  if (config.modules.logs) {
    const { logTicket } = require('./logs');
    await logTicket(interaction.guild, 'Ticket claim',
      `${interaction.user} a pris en charge ${salon}`, [], client);
  }
}

/** Transcript HTML puis fermeture du ticket */
async function transcript(interaction, client) {
  await interaction.deferReply();
  const salon = interaction.channel;
  const messages = await recupererMessages(salon);

  const html = construireHTML(salon, messages, client);
  const nomFichier = `transcript-${salon.name}-${Date.now()}.html`;
  const chemin = path.join(DOSSIER_TRANSCRIPTS, nomFichier);
  fs.writeFileSync(chemin, html);

  await interaction.editReply({
    embeds: [client.util.embed('📄 Transcript généré',
      `**${messages.length}** messages archivés.\nLe fichier HTML est joint ci-dessous.`)],
    files: [new AttachmentBuilder(chemin, { name: nomFichier })]
  });

  if (config.modules.logs) {
    const { logTicket } = require('./logs');
    await logTicket(interaction.guild, 'Transcript généré',
      `${interaction.user} a généré le transcript de ${salon.name} (${messages.length} messages)`, [], client);
  }
  return chemin;
}

async function fermer(interaction, client) {
  await interaction.reply({
    embeds: [client.util.embed('🔒 Fermeture du ticket',
      'Le transcript va être généré puis le salon supprimé dans **5 secondes**.')]
  });

  const salon = interaction.channel;
  const messages = await recupererMessages(salon);
  const html = construireHTML(salon, messages, client);
  const nomFichier = `transcript-${salon.name}-${Date.now()}.html`;
  const chemin = path.join(DOSSIER_TRANSCRIPTS, nomFichier);
  fs.writeFileSync(chemin, html);

  // Envoi du transcript en log tickets
  if (config.modules.logs) {
    const { salonLog } = require('./logs');
    const logChannel = await salonLog(interaction.guild, 'tickets');
    if (logChannel) {
      await logChannel.send({
        embeds: [client.util.embed('🔒 Ticket fermé',
          `**Salon :** ${salon.name}\n**Fermé par :** ${interaction.user}\n**Messages :** ${messages.length}`)],
        files: [new AttachmentBuilder(chemin, { name: nomFichier })]
      }).catch(() => {});
    }
  }

  setTimeout(() => salon.delete().catch(() => {}), 5000);
}

async function recupererMessages(salon) {
  const tous = [];
  let dernier = null;
  // Récupère jusqu'à 500 messages
  for (let i = 0; i < 5; i++) {
    const lot = await salon.messages.fetch({ limit: 100, before: dernier || undefined }).catch(() => null);
    if (!lot || lot.size === 0) break;
    tous.push(...lot.values());
    dernier = lot.last().id;
    if (lot.size < 100) break;
  }
  return tous.reverse();
}

function construireHTML(salon, messages, client) {
  const lignes = messages.map((m) => `
    <div class="message">
      <div class="entete">
        <span class="auteur">${client.util.html(client.util.nomComplet(m.author))}</span>
        <span class="date">${new Date(m.createdTimestamp).toLocaleString('fr-FR')}</span>
      </div>
      <div class="contenu">${client.util.html(m.content).replace(/\n/g, '<br>')}</div>
      ${m.attachments.size ? `<div class="pj">📎 ${[...m.attachments.values()].map((a) => `<a href="${a.url}">${client.util.html(a.name)}</a>`).join(' · ')}</div>` : ''}
    </div>`).join('\n');

  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Transcript — ${client.util.html(salon.name)}</title>
<style>
  :root { --bleu-fonce: #1B2A4A; --bleu-nuit: #0D1629; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 0; background: #f4f6fb; font-family: -apple-system, "Segoe UI", Roboto, sans-serif; color: #1a1a1a; }
  header { background: var(--bleu-fonce); color: #fff; padding: 28px 32px; }
  header h1 { margin: 0 0 6px; font-size: 22px; }
  header p { margin: 0; opacity: .8; font-size: 14px; }
  main { max-width: 900px; margin: 0 auto; padding: 24px 32px 60px; }
  .message { background: #fff; border-left: 4px solid var(--bleu-fonce); border-radius: 6px; padding: 12px 16px; margin-bottom: 10px; }
  .entete { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
  .auteur { font-weight: 600; color: var(--bleu-fonce); }
  .date { font-size: 12px; color: #6b7280; }
  .contenu { white-space: pre-wrap; line-height: 1.5; }
  .pj { margin-top: 8px; font-size: 13px; }
  .pj a { color: var(--bleu-fonce); }
  footer { text-align: center; padding: 24px; color: #6b7280; font-size: 13px; }
</style>
</head>
<body>
<header>
  <h1>Transcript — #${client.util.html(salon.name)}</h1>
  <p>Généré le ${new Date().toLocaleString('fr-FR')} · ${messages.length} messages</p>
</header>
<main>
${lignes || '<p>Aucun message dans ce ticket.</p>'}
</main>
<footer>Kova — gestion de serveur</footer>
</body>
</html>`;
}

/** Classement du staff (top claims) */
function classementStaff(client, guild) {
  const stats = client.db.lire('staff', {});
  const lignes = Object.entries(stats)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([id, n], i) => {
      const medailles = ['🥇', '🥈', '🥉'];
      return `${medailles[i] || `**${i + 1}.**`} <@${id}> — **${n}** ticket(s)`;
    });
  return lignes.length ? lignes.join('\n') : 'Aucun ticket pris en charge pour le moment.';
}

module.exports = {
  restaurerCompteurs,
  envoyerPanneau,
  ouvrirDepuisSelection,
  gererInteractionTicket,
  gererModalTicket: async () => {},
  transcript,
  fermer,
  classementStaff,
  construireHTML
};
