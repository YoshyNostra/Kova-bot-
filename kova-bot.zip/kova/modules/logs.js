/**
 * Module : Logs
 * Centralise tous les envois vers les 8 salons de logs.
 */
const { config } = require('../core');

/** Trouve (ou crée) le salon de logs pour une catégorie */
async function salonLog(guild, categorie) {
  const nomBase = config.salons.logs;
  let salon = guild.channels.cache.find((c) => c.name === `${nomBase}-${categorie}`);
  if (!salon) {
    salon = guild.channels.cache.find((c) => c.name === nomBase);
  }
  return salon || null;
}

async function envoyer(guild, categorie, cle, titre, description, champs = [], client) {
  if (!config.modules.logs) return;
  if (config.logs[cle] === false) return;
  const salon = await salonLog(guild, categorie);
  if (!salon) return;
  const embed = client.util.embed(titre, description, {
    champs,
    footer: 'Kova · Logs'
  });
  await salon.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  salonLog,
  logMessage: (g, t, d, c, cl) => envoyer(g, 'messages', 'messages', t, d, c, cl),
  logMembre: (g, t, d, c, cl) => envoyer(g, 'membres', 'membres', t, d, c, cl),
  logModeration: (g, t, d, c, cl) => envoyer(g, 'moderation', 'moderation', t, d, c, cl),
  logRole: (g, t, d, c, cl) => envoyer(g, 'roles', 'roles', t, d, c, cl),
  logSalon: (g, t, d, c, cl) => envoyer(g, 'salons', 'salons', t, d, c, cl),
  logVocal: (g, t, d, c, cl) => envoyer(g, 'vocal', 'vocal', t, d, c, cl),
  logSecurite: (g, t, d, c, cl) => envoyer(g, 'securite', 'securite', t, d, c, cl),
  logTicket: (g, t, d, c, cl) => envoyer(g, 'tickets', 'tickets', t, d, c, cl)
};
