/**
 * Module : Backup
 * Sauvegarde automatique des rôles et des salons dans un dossier configurable.
 * Railway : monte un volume et pointe BACKUP_DIR / DATA_DIR dessus pour
 * conserver les sauvegardes entre deux déploiements.
 */
const fs = require('fs');
const path = require('path');
const { config } = require('../core');

// Dossier des sauvegardes : dossier du module par défaut, surchargeable
const DOSSIER = process.env.BACKUP_DIR
  ? path.resolve(process.env.BACKUP_DIR)
  : path.resolve(__dirname, '..', 'backups');

fs.mkdirSync(DOSSIER, { recursive: true });

/** Capture l'état actuel d'un serveur */
async function capturer(guild) {
  const roles = guild.roles.cache
    .filter((r) => r.name !== '@everyone')
    .sort((a, b) => b.position - a.position)
    .map((r) => ({
      id: r.id, name: r.name, color: r.hexColor, hoist: r.hoist,
      mentionable: r.mentionable, permissions: r.permissions.bitfield.toString(), position: r.position
    }));

  const salons = guild.channels.cache.map((c) => ({
    id: c.id, name: c.name, type: c.type, parent: c.parent?.name || null,
    position: c.rawPosition ?? c.position, topic: c.topic || null
  }));

  const membres = guild.members.cache.map((m) => ({
    id: m.id, user: m.user.tag, roles: m.roles.cache.map((r) => r.name),
    rejoint: m.joinedTimestamp
  }));

  return {
    serveur: { id: guild.id, nom: guild.name, membres: guild.memberCount },
    date: new Date().toISOString(),
    roles, salons, membres
  };
}

/** Écrit une sauvegarde sur disque et purge les plus anciennes */
async function sauvegarder(guild, client) {
  const data = await capturer(guild);
  const nom = `${guild.id}-${Date.now()}.json`;
  const chemin = path.join(DOSSIER, nom);

  try {
    fs.mkdirSync(DOSSIER, { recursive: true });
    fs.writeFileSync(chemin, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('[backup:ecriture]', e.message);
    return null;
  }

  // Purge des plus anciennes
  try {
    const fichiers = fs.readdirSync(DOSSIER)
      .filter((f) => f.startsWith(guild.id))
      .sort();
    while (fichiers.length > config.backup.maxBackups) {
      fs.unlinkSync(path.join(DOSSIER, fichiers.shift()));
    }
  } catch (e) {
    console.error('[backup:purge]', e.message);
  }

  if (config.modules.logs) {
    const { logSalon } = require('./logs');
    await logSalon(guild, 'Sauvegarde effectuée',
      `**Fichier :** \`${nom}\`\n**Rôles :** ${data.roles.length} · **Salons :** ${data.salons.length}`, [], client);
  }
  return chemin;
}

/** Lance la sauvegarde périodique */
function demarrerSauvegardesAuto(client) {
  const intervalle = config.backup.intervalleHeures * 60 * 60 * 1000;
  console.log(`   💾 Module backup : sauvegarde toutes les ${config.backup.intervalleHeures} h → ${DOSSIER}`);

  setInterval(async () => {
    for (const guild of client.guilds.cache.values()) {
      await sauvegarder(guild, client).catch((e) => console.error('[backup]', e.message));
    }
  }, intervalle);

  // Première sauvegarde une minute après le démarrage
  setTimeout(async () => {
    for (const guild of client.guilds.cache.values()) {
      await sauvegarder(guild, client).catch((e) => console.error('[backup]', e.message));
    }
  }, 60_000);
}

/** Liste les sauvegardes d'un serveur */
function listerSauvegardes(guildId) {
  try {
    return fs.readdirSync(DOSSIER).filter((f) => f.startsWith(guildId)).sort().reverse();
  } catch {
    return [];
  }
}

module.exports = { capturer, sauvegarder, demarrerSauvegardesAuto, listerSauvegardes, DOSSIER };
