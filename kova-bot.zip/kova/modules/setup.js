/**
 * Module : Setup
 * Crée automatiquement les rôles, les catégories, les 8 salons de logs,
 * le panneau de tickets, la boutique et le règlement.
 */
const { config } = require('../core');
const { ChannelType, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

const SALONS_PUBLICS = ['reglement', 'annonces', 'boutique', 'tickets'];

/** Crée les rôles manquants */
async function creerRoles(guild, client) {
  const crees = [];
  const ordre = [
    { cle: 'staff', couleur: '#2E4272', hoist: true, perms: [PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.KickMembers, PermissionFlagsBits.BanMembers, PermissionFlagsBits.ModerateMembers] },
    { cle: 'moderateur', couleur: '#3D5A94', hoist: true, perms: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.KickMembers, PermissionFlagsBits.ModerateMembers, PermissionFlagsBits.ManageChannels] },
    { cle: 'vip', couleur: '#1B2A4A', hoist: true, perms: [] },
    { cle: 'membre', couleur: '#4A6FA5', hoist: false, perms: [] },
    { cle: 'mute', couleur: '#0D1629', hoist: false, perms: [], deny: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.Speak, PermissionFlagsBits.AddReactions] },
    { cle: 'nonVerifie', couleur: '#3A3A3A', hoist: false, perms: [] }
  ];

  for (const r of ordre) {
    const nom = config.roles[r.cle];
    if (guild.roles.cache.find((x) => x.name === nom)) continue;

    const role = await guild.roles.create({
      name: nom,
      color: r.couleur,
      hoist: r.hoist,
      mentionable: r.cle === 'staff' || r.cle === 'moderateur',
      permissions: r.perms,
      reason: 'Kova — /setup tout'
    }).catch(() => null);

    if (role && r.deny) {
      // Le rôle Muted se contente de ne pas avoir les permissions d'écriture
      await role.setPermissions(0n).catch(() => {});
    }
    if (role) crees.push(role.name);
  }
  return crees;
}

/** Crée les catégories et salons manquants */
async function creerSalons(guild, client) {
  const crees = [];

  const categorieLogs = guild.channels.cache.find((c) => c.name === 'Logs' && c.type === ChannelType.GuildCategory)
    || await guild.channels.create({ name: 'Logs', type: ChannelType.GuildCategory, reason: 'Kova — /setup tout' }).catch(() => null);

  const categorieTickets = guild.channels.cache.find((c) => c.name === config.salons.categorieTickets && c.type === ChannelType.GuildCategory)
    || await guild.channels.create({ name: config.salons.categorieTickets, type: ChannelType.GuildCategory, reason: 'Kova — /setup tout' }).catch(() => null);

  // Salons publics
  for (const nom of SALONS_PUBLICS) {
    if (guild.channels.cache.find((c) => c.name === nom)) continue;
    const c = await guild.channels.create({
      name: nom, type: ChannelType.GuildText,
      reason: 'Kova — /setup tout'
    }).catch(() => null);
    if (c) crees.push(c.name);
  }

  // Salon de tickets créé dans sa catégorie si le nom libre n'existe pas
  if (!guild.channels.cache.find((c) => c.name === config.salons.tickets) && categorieTickets) {
    const c = await guild.channels.create({
      name: config.salons.tickets, type: ChannelType.GuildText, parent: categorieTickets.id,
      reason: 'Kova — /setup tout'
    }).catch(() => null);
    if (c) crees.push(c.name);
  }

  // 8 salons de logs
  const categoriesLogs = ['messages', 'membres', 'moderation', 'roles', 'salons', 'vocal', 'securite', 'tickets'];
  for (const cat of categoriesLogs) {
    const nom = `${config.salons.logs}-${cat}`;
    if (guild.channels.cache.find((c) => c.name === nom)) continue;
    const c = await guild.channels.create({
      name: nom, type: ChannelType.GuildText,
      parent: categorieLogs ? categorieLogs.id : null,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] }
      ],
      reason: 'Kova — /setup tout'
    }).catch(() => null);
    if (c) {
      const roleStaff = client.util.role(guild, 'staff');
      const roleModo = client.util.role(guild, 'moderateur');
      for (const r of [roleStaff, roleModo]) {
        if (r) await c.permissionOverwrites.edit(r.id, { ViewChannel: true, SendMessages: true }).catch(() => {});
      }
      crees.push(c.name);
    }
  }

  // Salons VIP privés
  if (config.modules.vip) {
    const roleVip = client.util.role(guild, 'vip');
    for (const nom of config.vip.salonsPrives) {
      if (guild.channels.cache.find((c) => c.name === nom)) continue;
      const c = await guild.channels.create({
        name: nom, type: ChannelType.GuildText,
        permissionOverwrites: [
          { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
          ...(roleVip ? [{ id: roleVip.id, allow: [PermissionFlagsBits.ViewChannel] }] : [])
        ],
        reason: 'Kova — /setup tout'
      }).catch(() => null);
      if (c) crees.push(c.name);
    }
  }

  // Hub vocal temporaire
  if (config.modules.vocal) {
    for (const nom of config.vocal.hubs) {
      if (guild.channels.cache.find((c) => c.name === nom)) continue;
      const c = await guild.channels.create({
        name: nom, type: ChannelType.GuildVoice,
        reason: 'Kova — /setup tout'
      }).catch(() => null);
      if (c) crees.push(c.name);
    }
  }

  return crees;
}

/** Publie les panneaux (règlement, tickets, boutique) */
async function publierPanneaux(guild, client) {
  // Panneau de tickets
  if (config.modules.tickets) {
    const salon = client.util.salon(guild, config.salons.tickets);
    if (salon) {
      const ancien = await salon.messages.fetch({ limit: 20 }).catch(() => null);
      const dejaLa = ancien ? ancien.some((m) => m.author.id === client.user.id && m.components.length && m.embeds[0]?.title === '🎫 Ouvrir un ticket') : false;
      if (!dejaLa) {
        const { envoyerPanneau } = require('./tickets');
        await envoyerPanneau(salon, client);
      }
    }
  }

  // Boutique
  if (config.modules.vip) {
    const salon = client.util.salon(guild, config.salons.boutique);
    if (salon) {
      const ancien = await salon.messages.fetch({ limit: 20 }).catch(() => null);
      const dejaLa = ancien ? ancien.some((m) => m.author.id === client.user.id && m.embeds[0]?.title === '💎 Accès VIP') : false;
      if (!dejaLa) {
        const { envoyerPanneauVip } = require('./vip');
        await envoyerPanneauVip(salon, client);
      }
    }
  }

  // Règlement
  const salonReglement = client.util.salon(guild, config.salons.reglement);
  if (salonReglement) {
    const ancien = await salonReglement.messages.fetch({ limit: 20 }).catch(() => null);
    const dejaLa = ancien ? ancien.some((m) => m.author.id === client.user.id && m.embeds[0]?.title === `📜 Règlement de ${guild.name}`) : false;
    if (!dejaLa) {
      const reglement = client.util.embed(`📜 Règlement de ${guild.name}`,
        "**1.** Respecte tous les membres, sans exception.\n" +
        "**2.** Aucune publicité ni invitation vers un autre serveur.\n" +
        "**3.** Pas de contenu illégal, haineux ou choquant.\n" +
        "**4.** Pas de spam, de flood ou de mentions abusives.\n" +
        "**5.** Les décisions du staff sont à respecter.\n" +
        "**6.** Un salon = un sujet. Utilise le bon salon.\n\n" +
        "Tout manquement entraîne un avertissement, un mute, voire un bannissement."
      );
      await salonReglement.send({ embeds: [reglement] });
    }
  }
}

/** Setup complet */
async function setupComplet(guild, client, options = {}) {
  const rapport = { roles: [], salons: [], erreurs: [] };

  try {
    if (config.setup.creerRolesAutomatiquement && options.roles !== false) {
      rapport.roles = await creerRoles(guild, client);
    }
    if (config.setup.creerSalonsAutomatiquement && options.salons !== false) {
      rapport.salons = await creerSalons(guild, client);
    }
    await publierPanneaux(guild, client);
  } catch (e) {
    rapport.erreurs.push(e.message);
  }

  return rapport;
}

module.exports = { setupComplet, creerRoles, creerSalons, publierPanneaux };
