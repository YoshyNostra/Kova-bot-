/**
 * Module : Modération
 * ban / kick / mute / warn / blacklist + historique.
 */
const { config } = require('../core');

/** Formate une durée en millisecondes en texte lisible */
function ms(valeur, options = {}) {
  const unites = [
    ['jour', 'jours', 86_400_000],
    ['heure', 'heures', 3_600_000],
    ['minute', 'minutes', 60_000],
    ['seconde', 'secondes', 1000]
  ];
  for (const [sing, plur, mult] of unites) {
    if (valeur >= mult) {
      const n = Math.round(valeur / mult);
      return options.long ? `${n} ${n > 1 ? plur : sing}` : `${n}${sing[0]}`;
    }
  }
  return '0s';
}

async function envoyerDM(membre, embed) {
  if (!config.moderation.dmAuto) return;
  await membre.send({ embeds: [embed] }).catch(() => {});
}

async function avertir(guild, membre, raison, moderateur, client) {
  const warns = client.db.lire('warns', {});
  const cle = `${guild.id}:${membre.id}`;
  warns[cle] = warns[cle] || [];
  warns[cle].push({ raison, par: moderateur.id, date: Date.now() });
  client.db.ecrire('warns', warns);

  await envoyerDM(membre, client.util.embed('⚠️ Avertissement',
    `Tu as reçu un avertissement sur **${guild.name}**.\n**Raison :** ${raison}\n**Total :** ${warns[cle].length}`));

  if (config.moderation.avertissementAvantBlacklist &&
      warns[cle].length >= config.moderation.avertissementAvantBlacklist) {
    await blacklister(guild, membre, `atteinte de ${config.moderation.avertissementAvantBlacklist} avertissements`, moderateur, client);
    return { warns: warns[cle].length, blacklist: true };
  }
  return { warns: warns[cle].length, blacklist: false };
}

async function blacklister(guild, membre, raison, moderateur, client) {
  const liste = client.db.lire('blacklist', {});
  liste[guild.id] = liste[guild.id] || [];
  if (!liste[guild.id].includes(membre.id)) liste[guild.id].push(membre.id);
  client.db.ecrire('blacklist', liste);

  await guild.members.ban(membre.id, { reason: `Blacklist — ${raison}` }).catch(() => {});

  if (config.modules.logs) {
    const { logModeration } = require('./logs');
    await logModeration(guild, 'Blacklist',
      `${membre.user} a été blacklisté.\n**Raison :** ${raison}\n**Par :** ${moderateur}`, [], client);
  }
}

async function mute(guild, membre, duree, raison, moderateur, client) {
  const msDuree = client.util.duree(duree) || config.moderation.dureeMuteParDefautMinutes * 60 * 1000;
  await membre.timeout(msDuree, `Par ${moderateur.tag} — ${raison}`);
  await envoyerDM(membre, client.util.embed('🔇 Mute',
    `Tu es réduit au silence sur **${guild.name}**.\n**Durée :** ${ms(msDuree, { long: true })}\n**Raison :** ${raison}`));

  if (config.modules.logs) {
    const { logModeration } = require('./logs');
    await logModeration(guild, 'Mute',
      `${membre.user} — ${ms(msDuree, { long: true })}\n**Raison :** ${raison}\n**Par :** ${moderateur}`, [], client);
  }
}

module.exports = { avertir, blacklister, mute, envoyerDM };
