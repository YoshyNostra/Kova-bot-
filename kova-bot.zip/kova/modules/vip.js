/**
 * Module : VIP
 * Attribution / retrait du rôle VIP, paiement PayPal, gestion des visibilités.
 */
const { config } = require('../core');
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder,
  TextInputBuilder, TextInputStyle, ChannelType, PermissionFlagsBits
} = require('discord.js');

/** Panneau boutique VIP avec bouton d'achat */
async function envoyerPanneauVip(channel, client) {
  const embed = client.util.embed(
    '💎 Accès VIP',
    `Rejoins l'espace VIP de **${channel.guild.name}** et profite des avantages réservés.\n\n` +
    `**Avantages**\n` +
    `• Accès aux salons privés ${config.vip.salonsPrives.map((s) => `\`${s}\``).join(', ')}\n` +
    `• Rôle distinctif et couleur dédiée\n` +
    `• Priorité de traitement des tickets\n\n` +
    `**Durée :** ${config.vip.dureeJours} jours\n` +
    `**Tarif :** à régler via PayPal`
  ).addFields({ name: 'Paiement', value: `[Payer via PayPal](https://${config.vip.paypal})` });

  const boutons = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('vip_paiement').setLabel('J\'ai payé').setEmoji('💳').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('vip_statut').setLabel('Mon statut VIP').setEmoji('🔍').setStyle(ButtonStyle.Secondary)
  );

  await channel.send({ embeds: [embed], components: [boutons] });
}

/** Applique / retire la visibilité des salons VIP */
async function appliquerVisibilite(guild, roleVip, activer) {
  for (const nom of config.vip.salonsPrives) {
    const salon = client_salon(guild, nom);
    if (!salon) continue;
    if (activer) {
      await salon.permissionOverwrites.edit(roleVip.id, { ViewChannel: true }).catch(() => {});
    } else {
      await salon.permissionOverwrites.delete(roleVip.id).catch(() => {});
    }
  }
}

function client_salon(guild, nom) {
  return guild.channels.cache.find((c) => c.name === nom);
}

/** Attribue le rôle VIP pour une durée donnée */
async function attribuerVip(guild, membre, client) {
  const roleVip = client.util.role(guild, 'vip');
  if (!roleVip) return { ok: false, raison: 'Rôle VIP introuvable — lance `/setup tout`.' };

  await membre.roles.add(roleVip).catch(() => {});

  const vip = client.db.lire('vip', {});
  vip[membre.id] = {
    depuis: Date.now(),
    expiration: Date.now() + config.vip.dureeJours * 24 * 60 * 60 * 1000
  };
  client.db.ecrire('vip', vip);

  if (config.vip.roleVisibilite) await appliquerVisibilite(guild, roleVip, true);

  await membre.send({
    embeds: [client.util.embed('💎 Bienvenue chez les VIP',
      `Ton accès VIP sur **${guild.name}** est actif pour **${config.vip.dureeJours} jours**.\n` +
      `Expire le <t:${Math.floor(vip[membre.id].expiration / 1000)}:D>.`)]
  }).catch(() => {});

  return { ok: true, expiration: vip[membre.id].expiration };
}

/** Retire le rôle VIP */
async function retirerVip(guild, membre, client) {
  const roleVip = client.util.role(guild, 'vip');
  if (!roleVip) return false;
  await membre.roles.remove(roleVip).catch(() => {});
  const vip = client.db.lire('vip', {});
  delete vip[membre.id];
  client.db.ecrire('vip', vip);
  return true;
}

/** Vérifie les expirations — appelé périodiquement */
async function verifierExpirations(client) {
  const vip = client.db.lire('vip', {});
  const maintenant = Date.now();
  let modifies = false;

  for (const [userId, data] of Object.entries(vip)) {
    if (data.expiration && data.expiration < maintenant) {
      for (const guild of client.guilds.cache.values()) {
        const membre = await guild.members.fetch(userId).catch(() => null);
        if (membre) {
          await retirerVip(guild, membre, client);
          await membre.send({
            embeds: [client.util.embed('💎 Accès VIP expiré',
              `Ton accès VIP sur **${guild.name}** a pris fin. Merci pour ton soutien !`)]
          }).catch(() => {});
        }
      }
      delete vip[userId];
      modifies = true;
    }
  }
  if (modifies) client.db.ecrire('vip', vip);
}

/** Routage des boutons VIP */
async function gererInteractionVip(interaction, client) {
  if (interaction.customId === 'vip_paiement') {
    const modal = new ModalBuilder().setCustomId('vip_preuve').setTitle('Preuve de paiement');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('email').setLabel('E-mail PayPal utilisé').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('transaction').setLabel('Référence de transaction').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('note').setLabel('Information complémentaire').setStyle(TextInputStyle.Paragraph).setRequired(false))
    );
    return interaction.showModal(modal);
  }

  if (interaction.customId === 'vip_statut') {
    const vip = client.db.lire('vip', {});
    const data = vip[interaction.user.id];
    if (!data) {
      return interaction.reply({ content: "Tu n'as pas d'accès VIP actif.", ephemeral: true });
    }
    return interaction.reply({
      content: `💎 Ton accès VIP est actif jusqu'au <t:${Math.floor(data.expiration / 1000)}:F>.`,
      ephemeral: true
    });
  }
}

/** Traitement du modal de preuve de paiement */
async function gererModalVip(interaction, client) {
  const email = interaction.fields.getTextInputValue('email');
  const transaction = interaction.fields.getTextInputValue('transaction');
  const note = interaction.fields.getTextInputValue('note') || '—';

  const demandes = client.db.lire('vip_demandes', {});
  demandes[interaction.user.id] = { email, transaction, note, date: Date.now() };
  client.db.ecrire('vip_demandes', demandes);

  await interaction.reply({
    embeds: [client.util.embed('💳 Demande enregistrée',
      "Ta preuve de paiement a été transmise à l'équipe. Un membre du staff validera ton accès VIP sous peu.")],
    ephemeral: true
  });

  if (config.modules.logs) {
    const { logSecurite } = require('./logs');
    await logSecurite(interaction.guild, 'Demande VIP',
      `**Membre :** ${interaction.user}\n**E-mail :** \`${email}\`\n**Transaction :** \`${transaction}\`\n**Note :** ${note}`,
      [], client);
  }
}

module.exports = {
  envoyerPanneauVip,
  attribuerVip,
  retirerVip,
  verifierExpirations,
  gererInteractionVip,
  gererModalVip,
  appliquerVisibilite
};
