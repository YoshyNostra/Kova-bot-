/**
 * Module : Expiration
 * Vérifie périodiquement l'expiration des accès VIP et retire le rôle.
 */
const { config } = require('../core');
const { verifierExpirations } = require('./vip');

function demarrerExpirations(client) {
  if (!config.modules.vip) return;
  console.log('   ⏳ Surveillance des expirations VIP : toutes les 5 minutes');

  setInterval(() => {
    verifierExpirations(client).catch((e) => console.error('[expiration]', e.message));
  }, 5 * 60 * 1000);
}

module.exports = { demarrerExpirations };
