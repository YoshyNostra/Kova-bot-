/**
 * Événement : le bot est prêt.
 * Initialise les modules activés dans config.json.
 */
const { ActivityType } = require('discord.js');
const { config } = require('../core');

module.exports = {
  nom: 'clientReady',
  once: true,
  async executer(client) {
    console.log(`✅ Connecté en tant que ${client.user.tag}`);
    console.log(`   ${client.guilds.cache.size} serveur(s) · ${client.commandes.size} commandes slash · ${client.commandesPrefixe.size} commandes classiques`);

    client.user.setPresence({
      activities: [{ name: `${config.bot.prefix}aide · Kova`, type: ActivityType.Watching }],
      status: 'online'
    });

    // Modules activés
    const actifs = Object.entries(config.modules).filter(([, v]) => v).map(([k]) => k);
    console.log(`   Modules actifs : ${actifs.join(', ')}`);

    if (config.modules.backup) {
      const { demarrerSauvegardesAuto } = require('../modules/backup');
      demarrerSauvegardesAuto(client);
    }
    if (config.modules.securite) {
      const { initialiserSecurite } = require('../modules/securite');
      initialiserSecurite(client);
    }
    if (config.modules.tickets) {
      const { restaurerCompteurs } = require('../modules/tickets');
      restaurerCompteurs(client);
    }
  }
};
