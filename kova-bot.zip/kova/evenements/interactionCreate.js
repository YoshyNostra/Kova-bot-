/**
 * Événement : interaction (commandes slash, boutons, menus, modals).
 * Prise en charge complète du routage vers les modules.
 */
const { config } = require('../core');
const { PermissionFlagsBits } = require('discord.js');

module.exports = {
  nom: 'interactionCreate',
  async executer(interaction, client) {
    // --- Commandes slash ---
    if (interaction.isChatInputCommand()) {
      const cmd = client.commandes.get(interaction.commandName);
      if (!cmd) return;

      // Permission par défaut : gestion du serveur
      if (cmd.permission && !interaction.member.permissions.has(cmd.permission)) {
        return interaction.reply({ content: "Tu n'as pas la permission d'utiliser cette commande.", ephemeral: true });
      }

      try {
        await cmd.executer(interaction, client);
      } catch (e) {
        console.error(`[slash:${cmd.data.name}]`, e);
        const reponse = { content: 'Une erreur est survenue.', ephemeral: true };
        if (interaction.replied || interaction.deferred) interaction.followUp(reponse).catch(() => {});
        else interaction.reply(reponse).catch(() => {});
      }
      return;
    }

    // --- Boutons et menus : délégués au module tickets ---
    if (interaction.isStringSelectMenu() || interaction.isButton()) {
      const id = interaction.customId;
      if (id.startsWith('ticket_') || id.startsWith('staff_')) {
        if (!config.modules.tickets) return;
        const { gererInteractionTicket } = require('../modules/tickets');
        return gererInteractionTicket(interaction, client);
      }
      if (id.startsWith('vip_')) {
        if (!config.modules.vip) return;
        const { gererInteractionVip } = require('../modules/vip');
        return gererInteractionVip(interaction, client);
      }
      if (id.startsWith('ticket_ouvrir_')) {
        if (!config.modules.tickets) return;
        const { ouvrirDepuisSelection } = require('../modules/tickets');
        return ouvrirDepuisSelection(interaction, client);
      }
    }

    // --- Modals ---
    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith('ticket_')) {
        const { gererModalTicket } = require('../modules/tickets');
        return gererModalTicket(interaction, client);
      }
      if (interaction.customId.startsWith('vip_')) {
        const { gererModalVip } = require('../modules/vip');
        return gererModalVip(interaction, client);
      }
    }
  }
};
