/**
 * Événement : salon créé — logs salons.
 */
const { config } = require('../core');

module.exports = {
  nom: 'channelCreate',
  async executer(salon, client) {
    const guild = salon.guild;
    if (!guild) return;
    if (!config.modules.logs || !config.logs.salons) return;

    const { logSalon } = require('../modules/logs');
    await logSalon(guild, 'Salon créé',
      `**Nom :** \`${salon.name}\`\n**Type :** ${salon.type}`, [], client);
  }
};
