/**
 * Écouteur : départ d'un membre — nettoyage des données associées.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberRemove',
  async executer(member, client) {
    // Retire le membre de la liste VIP s'il part
    const vip = client.db.lire('vip', {});
    if (vip[member.id]) {
      delete vip[member.id];
      client.db.ecrire('vip', vip);
    }
  }
};
