/**
 * Événement : départ d'un membre.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberRemove',
  async executer(member, client) {
    if (!config.modules.logs || !config.logs.membres) return;
    const { logMembre } = require('../modules/logs');
    await logMembre(member.guild, 'Départ',
      `${member.user} (\`${client.util.nomComplet(member.user)}\`) a quitté le serveur.`,
      [{ name: 'Rejoint le', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Inconnu', inline: true },
       { name: 'Membres', value: `${member.guild.memberCount}`, inline: true }],
      client);
  }
};
