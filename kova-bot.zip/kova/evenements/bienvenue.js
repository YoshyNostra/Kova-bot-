/**
 * Écouteur : arrivée d'un membre — message de bienvenue personnalisé (si configuré).
 * Complète guildMemberAdd : le rôle par défaut et le log membre sont gérés par ailleurs.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberAdd',
  async executer(member, client) {
    const conf = client.db.lire('bienvenue', null);
    if (!conf || !conf.actif) return;

    const salon = member.guild.channels.cache.get(conf.salon);
    if (!salon) return;

    const texte = conf.texte
      .replace('{user}', `${member}`)
      .replace('{server}', member.guild.name)
      .replace('{membres}', `${member.guild.memberCount}`);

    await salon.send({ embeds: [client.util.embed('👋 Bienvenue', texte, { thumbnail: member.user.displayAvatarURL({ size: 256 }) })] }).catch(() => {});
  }
};
