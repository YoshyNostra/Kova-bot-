/**
 * Événement : arrivée d'un membre.
 * Anti-raid, filtre de comptes récents, attribution du rôle par défaut, log membre.
 */
const { config, client: _client } = require('../core');

module.exports = {
  nom: 'guildMemberAdd',
  async executer(member, client) {
    // --- Filtre de comptes récents + anti-raid ---
    if (config.modules.securite) {
      const { verifierArrivee } = require('../modules/securite');
      const rejete = await verifierArrivee(member, client);
      if (rejete) return;
    }

    // --- Rôle par défaut ---
    const roleMembre = client.util.role(member.guild, 'membre');
    if (roleMembre) {
      await member.roles.add(roleMembre).catch(() => {});
    }

    // --- Log membre ---
    if (config.modules.logs && config.logs.membres) {
      const { logMembre } = require('../modules/logs');
      await logMembre(member.guild, 'Arrivée',
        `${member.user} (\`${client.util.nomComplet(member.user)}\`) vient de rejoindre le serveur.`,
        [{ name: 'Compte créé', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
         { name: 'Membres', value: `${member.guild.memberCount}`, inline: true }],
        client);
    }
  }
};
