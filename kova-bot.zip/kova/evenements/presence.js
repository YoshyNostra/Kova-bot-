/**
 * Écouteur : mise à jour de la présence du bot (statut cyclique).
 * Affiche en alternance l'aide, le nombre de serveurs et la mention du préfixe.
 */
const { config } = require('../core');
const { ActivityType } = require('discord.js');

const statuts = [
  () => ({ name: `${config.bot.prefix}aide · /aide`, type: ActivityType.Watching }),
  () => ({ name: 'la sécurité du serveur 🛡️', type: ActivityType.Watching }),
  () => ({ name: 'les tickets 🎫', type: ActivityType.Listening })
];

module.exports = {
  nom: 'clientReady',
  async executer(client) {
    let i = 0;
    const maj = () => {
      const statut = statuts[i % statuts.length]();
      client.user.setPresence({ activities: [statut], status: 'online' });
      i++;
    };
    maj();
    setInterval(maj, 60_000);
  }
};
