/**
 * Événement : message modifié.
 */
const { config } = require('../core');

module.exports = {
  nom: 'messageUpdate',
  async executer(ancien, nouveau, client) {
    if (!nouveau.guild || !nouveau.author || nouveau.author.bot) return;
    if (ancien.content === nouveau.content) return;
    if (!config.modules.logs || !config.logs.messages) return;

    const { logMessage } = require('../modules/logs');
    await logMessage(nouveau.guild, 'Message modifié',
      `**Auteur :** ${nouveau.author} (\`${client.util.nomComplet(nouveau.author)}\`)\n**Salon :** ${nouveau.channel}\n**[Aller au message](${nouveau.url})**`,
      [
        { name: 'Avant', value: (ancien.content || '*inconnu*').slice(0, 1020) },
        { name: 'Après', value: (nouveau.content || '*inconnu*').slice(0, 1020) }
      ],
      client);
  }
};
