/**
 * Écouteur : le bot est retiré d'un serveur.
 */
module.exports = {
  nom: 'guildDelete',
  async executer(guild, client) {
    console.log(`➖ Retiré de : ${guild.name} (${guild.id})`);
  }
};
