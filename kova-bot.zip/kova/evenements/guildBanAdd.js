/**
 * Événement : bannissement.
 * Anti-nuke sur les bans massifs + log modération.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildBanAdd',
  async executer(ban, client) {
    if (config.modules.securite && config.securite.antiNuke) {
      const { signalerBan } = require('../modules/securite');
      await signalerBan(ban.guild, ban, client);
    }

    if (!config.modules.logs || !config.logs.moderation) return;
    const { logModeration } = require('../modules/logs');
    await logModeration(ban.guild, 'Bannissement',
      `${ban.user} (\`${client.util.nomComplet(ban.user)}\`) a été banni.`,
      [{ name: 'Raison', value: ban.reason || 'Non précisée' }],
      client);
  }
};
