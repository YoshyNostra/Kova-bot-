/**
 * Écouteur : réactions ajoutées/retirées — sert aux réaction-rôles par emoji.
 * Active la fonction en écrivant dans data/reactions.json :
 *   { "<messageId>": { "<emoji>": "<roleId>" } }
 */
const { config } = require('../core');

async function traiter(reaction, user, ajouter, client) {
  if (user.bot) return;
  const message = reaction.message;
  if (!message.guild) return;

  const conf = client.db.lire('reactions', null);
  if (!conf) return;

  const pourCeMessage = conf[message.id];
  if (!pourCeMessage) return;

  const cle = reaction.emoji.id || reaction.emoji.name;
  const roleId = pourCeMessage[cle] || pourCeMessage[reaction.emoji.name];
  if (!roleId) return;

  const role = message.guild.roles.cache.get(roleId);
  if (!role) return;

  const membre = await message.guild.members.fetch(user.id).catch(() => null);
  if (!membre) return;

  if (ajouter) await membre.roles.add(role).catch(() => {});
  else await membre.roles.remove(role).catch(() => {});
}

module.exports = [
  {
    nom: 'messageReactionAdd',
    async executer(reaction, user, client) {
      if (reaction.partial) await reaction.fetch().catch(() => {});
      await traiter(reaction, user, true, client);
    }
  },
  {
    nom: 'messageReactionRemove',
    async executer(reaction, user, client) {
      if (reaction.partial) await reaction.fetch().catch(() => {});
      await traiter(reaction, user, false, client);
    }
  }
];
