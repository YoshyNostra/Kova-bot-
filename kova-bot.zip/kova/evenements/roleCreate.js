/**
 * Événement : rôle créé / supprimé — logs rôles.
 */
const { config } = require('../core');

module.exports = [
  {
    nom: 'roleCreate',
    async executer(role, client) {
      if (!config.modules.logs || !config.logs.roles) return;
      const { logRole } = require('../modules/logs');
      await logRole(role.guild, 'Rôle créé',
        `**${role.name}** (\`${role.hexColor}\`)`, [], client);
    }
  },
  {
    nom: 'roleDelete',
    async executer(role, client) {
      if (!config.modules.logs || !config.logs.roles) return;
      const { logRole } = require('../modules/logs');
      await logRole(role.guild, 'Rôle supprimé',
        `**${role.name}**`, [], client);
    }
  }
];
