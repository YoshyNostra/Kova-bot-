/**
 * Écouteur : arrivée d'un membre — attribution du rôle « Non vérifié »
 * tant que le membre n'a pas accepté le règlement (si configuré).
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberAdd',
  async executer(member, client) {
    if (!config.modules.setup) return;
    const roleNonVerifie = client.util.role(member.guild, 'nonVerifie');
    if (!roleNonVerifie) return;
    await member.roles.add(roleNonVerifie).catch(() => {});
  }
};
