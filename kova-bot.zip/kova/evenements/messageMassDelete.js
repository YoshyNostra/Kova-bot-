/**
 * Écouteur : suppression groupée de messages (bulkDelete).
 * Journalise le nombre et remplit le dernier message pour !snipe.
 */
const { config } = require('../core');

module.exports = {
  nom: 'messageDeleteBulk',
  async executer(messages, channel, client) {
    if (!channel.guild) return;

    // Alimente le snipe avec le message le plus récent
    const plusRecent = messages.first();
    if (plusRecent && plusRecent.author && !plusRecent.author.bot) {
      const util2 = require('../commandes/prefixe/util2');
      if (typeof util2.enregistrerSnipe === 'function') util2.enregistrerSnipe(plusRecent);
    }

    if (!config.modules.logs || !config.logs.messages) return;
    const { logMessage } = require('../modules/logs');
    await logMessage(channel.guild, 'Suppression groupée',
      `**${messages.size}** messages supprimés dans ${channel}`, [], client);
  }
};
