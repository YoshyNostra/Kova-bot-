/**
 * Événement : état vocal.
 * Logs vocaux + salons vocaux temporaires.
 */
const { config } = require('../core');
const { ChannelType, PermissionFlagsBits } = require('discord.js');

const vocauxTemporaires = new Set();

module.exports = {
  nom: 'voiceStateUpdate',
  async executer(ancien, nouveau, client) {
    const guild = nouveau.guild || ancien.guild;
    if (!guild) return;

    // --- Salons vocaux temporaires ---
    if (config.modules.vocal && config.vocal.vocalTemporaire24h && nouveau.channelId) {
      const hub = nouveau.channel;
      if (hub && config.vocal.hubs.includes(hub.name) && !vocauxTemporaires.has(hub.id)) {
        const parent = hub.parentId;
        const nom = config.vocal.nomSalonTemporaire.replace('{user}', nouveau.member.user.username);
        const temporaire = await guild.channels.create({
          name: nom,
          type: ChannelType.GuildVoice,
          parent,
          bitrate: hub.bitrate
        }).catch(() => null);

        if (temporaire) {
          await temporaire.permissionOverwrites.edit(nouveau.id, {
            Connect: true, Speak: true, ManageChannels: false
          }).catch(() => {});
          await nouveau.member.voice.setChannel(temporaire).catch(() => {});
          vocauxTemporaires.add(temporaire.id);
        }
      }
    }

    // Suppression du vocal temporaire devenu vide
    if (config.modules.vocal && ancien.channelId && ancien.channel && vocauxTemporaires.has(ancien.channelId)) {
      if (ancien.channel.members.size === 0) {
        await ancien.channel.delete().catch(() => {});
        vocauxTemporaires.delete(ancien.channelId);
      }
    }

    // --- Logs vocaux ---
    if (!config.modules.logs || !config.logs.vocal) return;
    const { logVocal } = require('../modules/logs');

    if (!ancien.channelId && nouveau.channelId) {
      await logVocal(guild, 'Connexion vocale',
        `${nouveau.member.user} a rejoint **${nouveau.channel.name}**`, client);
    } else if (ancien.channelId && !nouveau.channelId) {
      await logVocal(guild, 'Déconnexion vocale',
        `${nouveau.member.user} a quitté **${ancien.channel.name}**`, client);
    } else if (ancien.channelId !== nouveau.channelId) {
      await logVocal(guild, 'Déplacement vocal',
        `${nouveau.member.user} : **${ancien.channel.name}** → **${nouveau.channel.name}**`, client);
    } else if (ancien.serverMute !== nouveau.serverMute) {
      await logVocal(guild, nouveau.serverMute ? 'Mute vocal' : 'Démute vocal',
        `${nouveau.member.user} a été ${nouveau.serverMute ? 'rendu muet' : 'démuté'} par le serveur.`, client);
    }
  }
};
