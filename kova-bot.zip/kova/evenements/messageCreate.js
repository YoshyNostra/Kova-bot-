/**
 * Événement : message reçu.
 * Gère les commandes classiques (préfixe), l'anti-pub et les expéditeurs.
 */
const { config } = require('../core');
const { gererAntiPub } = require('../modules/securite');

module.exports = {
  nom: 'messageCreate',
  async executer(message, client) {
    if (!message.guild || message.author.bot) return;

    // --- Anti-pub / anti-liens (module sécurité) ---
    if (config.modules.securite && config.securite.antiPub) {
      const intercepte = await gererAntiPub(message, client);
      if (intercepte) return;
    }

    // --- Commandes classiques ---
    const prefixe = config.bot.prefix;
    if (!message.content.startsWith(prefixe)) return;

    const args = message.content.slice(prefixe.length).trim().split(/\s+/);
    const nom = args.shift().toLowerCase();
    const cmd = client.commandesPrefixe.get(nom);
    if (!cmd) return;

    // Cooldown 3 s par utilisateur et par commande
    const cle = `${cmd.nom}-${message.author.id}`;
    const maintenant = Date.now();
    if (client.cooldowns.has(cle)) {
      const expiration = client.cooldowns.get(cle) + 3000;
      if (maintenant < expiration) {
        return message.reply(`Doucement ! Réessaie dans ${((expiration - maintenant) / 1000).toFixed(1)} s.`);
      }
    }
    client.cooldowns.set(cle, maintenant);
    setTimeout(() => client.cooldowns.delete(cle), 3000);

    // Vérification de permission
    if (cmd.permission && !message.member.permissions.has(cmd.permission)) {
      return message.reply("Tu n'as pas la permission d'utiliser cette commande.");
    }

    try {
      await cmd.executer(message, args, client);
    } catch (e) {
      console.error(`[prefixe:${cmd.nom}]`, e);
      message.reply('Une erreur est survenue pendant l\'exécution de la commande.').catch(() => {});
    }
  }
};
