/**
 * Événement : mise à jour d'un membre (rôles, pseudo, timeout).
 * Sert aussi de capteur anti-nuke pour les changements de rôles.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberUpdate',
  async executer(ancien, nouveau, client) {
    const guild = nouveau.guild;

    // --- Détection anti-nuke : changement de rôle sur un autre membre ---
    const ajoutes = nouveau.roles.cache.filter((r) => !ancien.roles.cache.has(r.id));
    const retires = ancien.roles.cache.filter((r) => !nouveau.roles.cache.has(r.id));

    if (config.modules.securite && config.securite.antiNuke && (ajoutes.size || retires.size)) {
      const { signalerChangementRole } = require('../modules/securite');
      await signalerChangementRole(guild, nouveau, ajoutes, retires, client);
    }

    // --- Logs rôles ---
    if (config.modules.logs && config.logs.roles) {
      if (ajoutes.size) {
        const { logRole } = require('../modules/logs');
        await logRole(guild, 'Rôles ajoutés',
          `${nouveau.user} → ${ajoutes.map((r) => r.toString()).join(', ')}`, client);
      }
      if (retires.size) {
        const { logRole } = require('../modules/logs');
        await logRole(guild, 'Rôles retirés',
          `${nouveau.user} → ${retires.map((r) => r.toString()).join(', ')}`, client);
      }
    }

    // --- Logs pseudo ---
    if (config.modules.logs && config.logs.membres && ancien.nickname !== nouveau.nickname) {
      const { logMembre } = require('../modules/logs');
      await logMembre(guild, 'Pseudo modifié',
        `${nouveau.user} : **${ancien.nickname || ancien.user.username}** → **${nouveau.nickname || nouveau.user.username}**`,
        [], client);
    }
  }
};
