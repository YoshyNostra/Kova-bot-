/**
 * Écouteur : création d'un serveur absent de la config.
 * Prévient le propriétaire que /setup tout est disponible.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildCreate',
  async executer(guild, client) {
    console.log(`➕ Nouveau serveur : ${guild.name} (${guild.memberCount} membres)`);

    const salon = guild.systemChannel || guild.channels.cache.find((c) =>
      c.type === 0 && c.permissionsFor(client.user)?.has('SendMessages'));

    if (salon) {
      await salon.send({
        embeds: [client.util.embed('👋 Merci de m\'avoir invité !',
          `Je suis **Kova**, ton bot de gestion complète.\n\n` +
          `**Pour commencer :** tape \`/setup verifier\` puis \`/setup tout\` : je crée moi-même mes rôles, mes salons et mes panneaux.\n\n` +
          `**Ensuite :** \`/aide\` liste toutes les commandes disponibles.`,
          { footer: 'Kova · thème bleu foncé' })]
      }).catch(() => {});
    }
  }
};
