/**
 * Écouteur : arrivée d'un membre — compte à rebours du filtre de comptes récents.
 * Complète le module sécurité en informant le membre rejeté.
 */
const { config } = require('../core');

module.exports = {
  nom: 'guildMemberAdd',
  async executer(member, client) {
    if (!config.modules.securite || !config.securite.filtreComptesRecents) return;

    const ageMs = Date.now() - member.user.createdTimestamp;
    const seuil = config.securite.filtreComptesRecentsJours * 24 * 60 * 60 * 1000;
    if (ageMs >= seuil) return;

    // Le membre est trop récent : prévenir en privé puis tenter de le sortir
    await member.send({
      embeds: [client.util.embed('🚫 Accès refusé',
        `Ton compte est trop récent pour rejoindre **${member.guild.name}**.\n` +
        `Il doit avoir au moins **${config.securite.filtreComptesRecentsJours} jours**.\n` +
        `Réessaie le <t:${Math.floor((member.user.createdTimestamp + seuil) / 1000)}:F>.`)]
    }).catch(() => {});
  }
};
