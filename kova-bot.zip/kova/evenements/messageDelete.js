/**
 * Événement : message supprimé.
 * Alimente !snipe et le salon logs-messages.
 */
const { config } = require('../core');

module.exports = {
  nom: 'messageDelete',
  async executer(message, client) {
    if (!message.guild || !message.author || message.author.bot) return;

    // Alimentation du snipe
    const util2 = require('../commandes/prefixe/util2');
    if (typeof util2.enregistrerSnipe === 'function') util2.enregistrerSnipe(message);

    if (!config.modules.logs || !config.logs.messages) return;
    const { logMessage } = require('../modules/logs');
    await logMessage(message.guild, 'Message supprimé',
      `**Auteur :** ${message.author} (\`${client.util.nomComplet(message.author)}\`)\n**Salon :** ${message.channel}`,
      [{ name: 'Contenu', value: (message.content || '*inconnu (message non mis en cache)*').slice(0, 1020) }],
      client);
  }
};
