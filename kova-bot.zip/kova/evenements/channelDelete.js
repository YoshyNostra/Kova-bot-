/**
 * Événement : salon supprimé.
 * Anti-nuke sur les suppressions massives + logs salons.
 */
const { config } = require('../core');

module.exports = {
  nom: 'channelDelete',
  async executer(salon, client) {
    const guild = salon.guild;
    if (!guild) return;

    if (config.modules.securite && config.securite.antiNuke) {
      const { signalerSuppressionSalon } = require('../modules/securite');
      await signalerSuppressionSalon(guild, salon, client);
    }

    if (config.modules.logs && config.logs.salons) {
      const { logSalon } = require('../modules/logs');
      await logSalon(guild, 'Salon supprimé',
        `**Nom :** \`${salon.name}\`\n**Type :** ${salon.type}`, [], client);
    }
  }
};
