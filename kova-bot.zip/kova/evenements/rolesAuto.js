/**
 * Écouteur : menu de rôles à la carte (!reactionrole).
 */
const { config } = require('../core');

module.exports = {
  nom: 'interactionCreate',
  async executer(interaction, client) {
    if (!interaction.isStringSelectMenu()) return;
    if (interaction.customId !== 'roles_auto') return;

    await interaction.deferReply({ ephemeral: true });

    const ajoutes = [];
    const retires = [];

    for (const roleId of interaction.component.options.map((o) => o.value)) {
      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) continue;
      const leRoleEstChoisi = interaction.values.includes(roleId);
      const leMembreAlaRole = interaction.member.roles.cache.has(roleId);

      if (leRoleEstChoisi && !leMembreAlaRole) {
        await interaction.member.roles.add(role).catch(() => {});
        ajoutes.push(role.name);
      } else if (!leRoleEstChoisi && leMembreAlaRole) {
        await interaction.member.roles.remove(role).catch(() => {});
        retires.push(role.name);
      }
    }

    const parties = [];
    if (ajoutes.length) parties.push(`Ajoutés : ${ajoutes.join(', ')}`);
    if (retires.length) parties.push(`Retirés : ${retires.join(', ')}`);

    await interaction.editReply(parties.length ? `✅ ${parties.join(' — ')}` : 'Aucun changement.');
  }
};
