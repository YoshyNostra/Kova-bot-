/**
 * Écouteur : mise à jour de l'état vocal — journalisation détaillée
 * des changements de statut (auto-mute, sourdine, stream).
 */
const { config } = require('../core');

module.exports = {
  nom: 'voiceStateUpdate',
  async executer(ancien, nouveau, client) {
    const guild = nouveau.guild || ancien.guild;
    if (!guild || !nouveau.member) return;
    if (!config.modules.logs || !config.logs.vocal) return;
    if (ancien.channelId !== nouveau.channelId) return; // déjà journalisé ailleurs

    const { logVocal } = require('../modules/logs');

    if (ancien.selfMute !== nouveau.selfMute) {
      await logVocal(guild, nouveau.selfMute ? 'Micro coupé' : 'Micro réactivé',
        `${nouveau.member.user} dans **${nouveau.channel?.name || '—'}**`, [], client);
    }
    if (ancien.selfDeaf !== nouveau.selfDeaf) {
      await logVocal(guild, nouveau.selfDeaf ? 'Casque coupé' : 'Casque réactivé',
        `${nouveau.member.user} dans **${nouveau.channel?.name || '—'}**`, [], client);
    }
    if (ancien.streaming !== nouveau.streaming) {
      await logVocal(guild, nouveau.streaming ? 'Partage d\'écran démarré' : 'Partage d\'écran arrêté',
        `${nouveau.member.user} dans **${nouveau.channel?.name || '—'}**`, [], client);
    }
  }
};
